# Portal CJR — Documentação Completa
## Documento 11: Roadmap Futuro

---

## 11.1 Bugs Conhecidos (Pendentes de Correção)

Os seguintes bugs foram identificados no checkpoint `8317a97c` e ainda não foram corrigidos:

| # | Bug | Componente | Impacto |
|---|---|---|---|
| 1 | Erro `toISOString` no cronograma automático de preventivas | `server/routers/manutencao.ts` | Médio — cronograma pode falhar em alguns casos |
| 2 | Botão de envio de orçamento sumiu no admin | `AdminManutencao.tsx` | Alto — admin não consegue enviar orçamentos pela aba |
| 3 | Comprovante de material voltando para status "pendente" após upload | `clientAuth.ts` | Alto — cliente precisa reenviar comprovante |
| 4 | Aba Financeiro mostrando R$ 0,00 | `_clientDetail.ts` | Médio — cálculo financeiro incorreto |

---

## 11.2 Melhorias de Curto Prazo (1-3 meses)

### Notificações em Tempo Real
Implementar notificações push para alertar clientes e técnicos sobre:
- Nova solicitação de material pendente
- Orçamento enviado pelo admin
- Resposta do cliente ao orçamento
- Visita agendada/reagendada

**Tecnologia sugerida:** WebSockets via `socket.io` ou Server-Sent Events

---

### Envio Automático de E-mail
Configurar envio automático de e-mails para:
- Boas-vindas ao novo cliente (com link de criação de senha)
- Lembrete de preventiva (3 dias antes)
- Confirmação de aprovação de material
- Notificação de novo orçamento

**Tecnologia:** Nodemailer (já instalado) ou Resend (já instalado)

---

### Relatório de Preventiva Melhorado
- Incluir dados da loja (endereço, shopping) no cabeçalho do PDF
- Adicionar QR Code no rodapé para verificação de autenticidade
- Opção de envio automático do PDF por e-mail ao cliente após conclusão

---

### Dashboard Administrativo Aprimorado
- Gráfico de receita mensal (últimos 12 meses)
- Mapa de calor de chamados por região/shopping
- Indicadores de SLA (tempo médio de resolução de chamados)
- Alertas de clientes inadimplentes

---

### App Mobile (PWA)
Transformar o portal do técnico em Progressive Web App (PWA) para:
- Funcionamento offline (checklist sem internet)
- Câmera nativa do dispositivo para fotos
- Geolocalização automática do check-in/check-out
- Notificações push nativas

---

## 11.3 Melhorias de Médio Prazo (3-6 meses)

### Módulo de Contratos Digitais
- Geração automática de contrato em PDF ao ativar cliente
- Assinatura digital do contrato via DocuSign ou similar
- Histórico de versões do contrato

---

### Integração com WhatsApp Business
- Envio automático de mensagens via WhatsApp para:
  - Confirmação de agendamento
  - Lembrete de preventiva
  - Status de chamados
- Chatbot para abertura de chamados via WhatsApp

---

### Módulo de Faturamento
- Geração automática de boletos/NFS-e
- Integração com sistemas de contabilidade (Omie, ContaAzul)
- Controle de inadimplência com alertas automáticos
- Histórico de pagamentos por cliente

---

### Gestão de Estoque de Materiais
- Controle de estoque de materiais frequentemente usados
- Alertas de estoque mínimo
- Integração com solicitações de material dos técnicos
- Relatório de consumo por cliente/loja

---

### Portal de Relatórios Gerenciais
- Relatório de produtividade por técnico
- Relatório de recorrência de problemas por tipo
- Análise de custo por cliente
- Exportação para Excel/PDF

---

## 11.4 Melhorias de Longo Prazo (6-12 meses)

### Inteligência Artificial para Manutenção Preditiva
- Análise de padrões nos checklists para prever falhas
- Sugestão automática de frequência de visitas por tipo de loja
- Classificação automática de chamados por urgência via NLP

---

### Marketplace de Materiais
- Catálogo de materiais com preços de fornecedores parceiros
- Cotação automática ao criar solicitação de material
- Compra direta pelo portal com entrega na loja

---

### Multi-empresa
- Suporte a múltiplas empresas de manutenção na mesma plataforma
- Isolamento completo de dados por empresa
- Painel de super-admin para gestão de todas as empresas

---

### Integração com IoT
- Sensores de temperatura e umidade nas lojas
- Alertas automáticos de anomalias
- Histórico de dados ambientais nos relatórios de preventiva

---

## 11.5 Débitos Técnicos

| Item | Prioridade | Descrição |
|---|---|---|
| Testes unitários | Alta | Cobertura de testes para lógica de negócio crítica |
| Tratamento de erros | Alta | Melhorar mensagens de erro para o usuário final |
| Paginação | Média | Adicionar paginação nas listagens (clientes, visitas, chamados) |
| Cache | Média | Implementar cache de queries frequentes (Redis) |
| Logs estruturados | Média | Implementar logging estruturado (Winston/Pino) |
| Auditoria | Baixa | Expandir `actionLogs` para cobrir mais ações do sistema |
| Internacionalização | Baixa | Suporte a múltiplos idiomas (i18n) |
| Acessibilidade | Baixa | Melhorar conformidade com WCAG 2.1 |
| Performance | Baixa | Otimizar queries N+1 no Drizzle ORM |
| Documentação de código | Baixa | Adicionar JSDoc nas funções principais |

---

## 11.6 Sugestões de Arquitetura Futura

### Separação de Serviços
À medida que o sistema crescer, considerar separar em microserviços:
- **Serviço de Autenticação:** OAuth + sessões de cliente/técnico
- **Serviço de Manutenção:** Lógica de negócio principal
- **Serviço de Notificações:** E-mail, WhatsApp, push
- **Serviço de Relatórios:** Geração de PDFs e relatórios

### Migração para PostgreSQL
O TiDB/MySQL tem limitações para queries analíticas complexas. Considerar migração para PostgreSQL com extensão TimescaleDB para dados de séries temporais (histórico de visitas, métricas).

### CDN para Assets
Configurar CDN (CloudFront) para servir os PDFs e imagens armazenados no S3, melhorando a performance de carregamento dos relatórios.
