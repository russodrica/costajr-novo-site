# Portal CJR — Documentação Completa
## Documento 08: Manual de Implantação

---

## 8.1 Pré-requisitos

| Requisito | Versão Mínima | Observação |
|---|---|---|
| Node.js | 22.x | Recomendado: 22.13.0 |
| pnpm | 9.x | Gerenciador de pacotes |
| MySQL / TiDB | 8.x / compatível | Banco de dados principal |
| AWS S3 | — | Armazenamento de arquivos |
| Conta Manus | — | Para OAuth e APIs built-in |
| Conta Mercado Pago | — | Para pagamentos online |

---

## 8.2 Instalação Local (Desenvolvimento)

### Passo 1: Clonar o Repositório

```bash
git clone <URL_DO_REPOSITÓRIO> forum-cjr
cd forum-cjr
```

### Passo 2: Instalar Dependências

```bash
pnpm install
```

### Passo 3: Configurar Variáveis de Ambiente

Crie o arquivo `.env` na raiz do projeto com base no template abaixo:

```env
# Banco de Dados
DATABASE_URL=mysql://usuario:senha@host:3306/forum_cjr

# Autenticação JWT
JWT_SECRET=sua_chave_secreta_muito_longa_e_aleatoria

# Manus OAuth (fornecido pela plataforma Manus)
VITE_APP_ID=seu_app_id_manus
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://accounts.manus.im
OWNER_OPEN_ID=seu_open_id
OWNER_NAME=Nome do Proprietário

# Manus Built-in APIs (fornecido pela plataforma Manus)
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=sua_chave_api_manus
VITE_FRONTEND_FORGE_API_KEY=sua_chave_api_frontend
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im

# Analytics (opcional)
VITE_ANALYTICS_ENDPOINT=https://analytics.manus.im
VITE_ANALYTICS_WEBSITE_ID=seu_website_id

# Mercado Pago
MERCADO_PAGO_ACCESS_TOKEN=seu_access_token
MERCADO_PAGO_CLIENT_ID=seu_client_id
MERCADO_PAGO_CLIENT_SECRET=seu_client_secret
MERCADO_PAGO_PUBLIC_KEY=sua_public_key

# App
VITE_APP_TITLE=Portal CJR
VITE_APP_LOGO=/logo.png
VITE_APP_ID=forum-cjr
```

> **Nota:** Em ambiente Manus, as variáveis são injetadas automaticamente pela plataforma. O arquivo `.env` é necessário apenas para desenvolvimento local.

### Passo 4: Criar as Tabelas do Banco

```bash
pnpm db:push
```

Este comando executa `drizzle-kit generate` + `drizzle-kit migrate` para criar/atualizar todas as tabelas.

### Passo 5: Iniciar o Servidor de Desenvolvimento

```bash
pnpm dev
```

O servidor estará disponível em `http://localhost:3000`.

---

## 8.3 Scripts Disponíveis

| Script | Comando | Descrição |
|---|---|---|
| Desenvolvimento | `pnpm dev` | Inicia servidor com hot reload (tsx watch) |
| Build | `pnpm build` | Compila frontend (Vite) + backend (esbuild) |
| Testes | `pnpm test` | Executa testes Vitest |
| DB Push | `pnpm db:push` | Aplica alterações do schema ao banco |
| DB Studio | `pnpm db:studio` | Abre Drizzle Studio (UI do banco) |

---

## 8.4 Estrutura de Configuração

### `drizzle.config.ts` — Configuração do Drizzle

```typescript
export default {
  schema: "./drizzle/schema.ts",
  out: "./drizzle/migrations",
  dialect: "mysql",
  dbCredentials: {
    url: process.env.DATABASE_URL!,
  },
};
```

### `vite.config.ts` — Configuração do Vite

O Vite é configurado com:
- Plugin React para JSX
- Plugin Manus Runtime (injeção de variáveis de ambiente)
- Proxy de `/api` para o servidor Express em desenvolvimento

### `server/_core/env.ts` — Variáveis de Ambiente no Servidor

Todas as variáveis de ambiente do servidor são acessadas via este arquivo. **Não acesse `process.env` diretamente** no código de aplicação — use sempre `env.ts`.

---

## 8.5 Deploy em Produção (Plataforma Manus)

O projeto é hospedado na plataforma Manus com deploy automático.

### Processo de Deploy

1. Faça as alterações no código
2. Salve um checkpoint: `webdev_save_checkpoint`
3. Clique no botão **Publish** na interface da plataforma Manus
4. O sistema fará o build e deploy automaticamente

### Domínios Configurados

- `portalcjr.vip` (domínio principal)
- `www.portalcjr.vip`
- `cjrforum-a6rpmdtf.manus.space` (domínio Manus padrão)

---

## 8.6 Configuração do Banco de Dados

### Conexão

O banco usa MySQL/TiDB. A string de conexão segue o formato:

```
mysql://USUARIO:SENHA@HOST:PORTA/NOME_DO_BANCO
```

### Migrações

O Drizzle ORM gerencia as migrações. Para aplicar alterações no schema:

```bash
# Gera arquivos de migração
pnpm drizzle-kit generate

# Aplica as migrações
pnpm drizzle-kit migrate

# Atalho que faz os dois
pnpm db:push
```

> **Atenção:** O comando `db:push` aplica as alterações diretamente. Em produção, sempre faça backup antes de executar migrações.

---

## 8.7 Configuração do S3

O armazenamento de arquivos usa AWS S3 via helper `server/storage.ts`.

### Configuração

As credenciais S3 são injetadas automaticamente pela plataforma Manus via `BUILT_IN_FORGE_API_KEY` e `BUILT_IN_FORGE_API_URL`.

### Uso no Código

```typescript
import { storagePut } from "../storage";

// Upload de arquivo
const fileKey = `clients/${clientId}/receipts/${Date.now()}-receipt.pdf`;
const { url } = await storagePut(fileKey, fileBuffer, "application/pdf");

// url é a URL pública do arquivo no S3
```

---

## 8.8 Configuração do Mercado Pago

### Variáveis Necessárias

```env
MERCADO_PAGO_ACCESS_TOKEN=APP_USR-...
MERCADO_PAGO_CLIENT_ID=...
MERCADO_PAGO_CLIENT_SECRET=...
MERCADO_PAGO_PUBLIC_KEY=APP_USR-...
```

### Obtenção das Credenciais

1. Acesse [mercadopago.com.br/developers](https://mercadopago.com.br/developers)
2. Crie uma aplicação
3. Copie as credenciais de produção (ou sandbox para testes)

---

## 8.9 Configuração do Manus OAuth

O Manus OAuth é usado para autenticação dos colaboradores internos da CJR.

### Variáveis Necessárias

```env
VITE_APP_ID=forum-cjr
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://accounts.manus.im
```

### Fluxo OAuth

1. Frontend redireciona para `VITE_OAUTH_PORTAL_URL/login?app_id=VITE_APP_ID&state=...`
2. Usuário faz login no portal Manus
3. Manus redireciona para `/api/oauth/callback?code=...&state=...`
4. Servidor troca o code por token e cria sessão
5. Usuário é redirecionado para a URL original

---

## 8.10 Primeiro Acesso ao Sistema

### Configurar o Primeiro Administrador

1. Acesse o portal e faça login via Manus OAuth
2. No banco de dados, atualize o `role` do usuário para `"admin"`:

```sql
UPDATE users SET role = 'admin', approvalStatus = 'approved' 
WHERE email = 'seu@email.com';
```

3. Acesse `/admin/manutencao` para começar a configurar o sistema

### Configurações Iniciais Recomendadas

1. **Tabela de preços:** Acesse a aba "Preços" e configure os valores base por tipo de loja
2. **Texto do contrato:** Acesse a aba "Contrato" e insira o texto do contrato de adesão
3. **Primeiro cliente:** Acesse a aba "Clientes" e cadastre o primeiro cliente
4. **Primeiro técnico:** Acesse a aba "Técnicos" e cadastre o primeiro técnico

---

## 8.11 Monitoramento e Logs

### Logs do Servidor

Em desenvolvimento, os logs são exibidos no terminal. Em produção na plataforma Manus, os logs estão disponíveis em:

- `.manus-logs/devserver.log` — Logs do servidor
- `.manus-logs/browserConsole.log` — Logs do browser
- `.manus-logs/networkRequests.log` — Requisições HTTP

### Verificação de Saúde

Para verificar se o servidor está rodando:

```bash
curl http://localhost:3000/api/trpc/auth.me
```

Resposta esperada: `{"result":{"data":{"json":null}}}` (usuário não autenticado)
