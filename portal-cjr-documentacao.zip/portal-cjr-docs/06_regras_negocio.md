# Portal CJR — Documentação Completa
## Documento 06: Regras de Negócio

---

## 6.1 Precificação de Planos

### Tabela de Preços Base (por tipo de loja)

| Tipo de Loja | Preço Base Mensal |
|---|---|
| Quiosque | R$ 250,00 |
| Até 40 m² | R$ 280,00 |
| 41 a 80 m² | R$ 300,00 |
| 81 a 120 m² | R$ 400,00 |
| 120 a 250 m² | R$ 650,00 |

### Serviços Adicionais

O primeiro serviço (Elétrica, Hidráulica ou Civil) já está incluído no preço base. Cada serviço adicional além do primeiro acrescenta **R$ 65,00** ao valor mensal.

**Exemplos:**
- 1 serviço: preço base
- 2 serviços: preço base + R$ 65,00
- 3 serviços: preço base + R$ 130,00

### Multiplicadores por Plano

| Plano | Multiplicador | Meses | Desconto |
|---|---|---|---|
| Trimestral | 1,00 (sem desconto) | 3 | 0% |
| Semestral | 0,96 | 6 | 4% |
| Anual | 0,92 | 12 | 8% |

### Fórmula de Cálculo

```
monthly = round((base + (max(0, services - 1) * 65)) * multiplier)
total = monthly * planMonths
savings = (base + additionalCost) * planMonths - total
```

**Exemplo prático:** Loja de 41-80 m², 2 serviços, plano anual:
- Base: R$ 300,00
- Adicional: R$ 65,00
- Subtotal: R$ 365,00
- Multiplicador anual: 0,92
- Mensal: R$ 336,00 (arredondado)
- Total: R$ 4.032,00
- Economia: R$ 348,00

---

## 6.2 Cronograma Automático de Preventivas

Ao ativar um cliente, o admin pode gerar automaticamente o cronograma completo de visitas preventivas para o período do plano.

### Regras de Geração

| Plano | Total de Visitas | Frequência |
|---|---|---|
| Trimestral | 3 | 1 por mês |
| Semestral | 6 | 1 por mês |
| Anual | 12 | 1 por mês |

### Regras de Espaçamento

- **1ª visita:** data informada pelo admin (ou data atual se não informada)
- **2ª visita:** 1ª visita + 10 dias
- **3ª visita em diante:** visita anterior + 30 dias

### Dados Gerados por Visita

- `clientId`: ID do cliente
- `scheduledDate`: data calculada
- `scheduledTime`: `"09:00"` (padrão)
- `status`: `"agendada"`
- `adminNotes`: `"Preventiva N/Total — gerada automaticamente (plano TIPO)"`

---

## 6.3 Fluxo de Aprovação de Orçamentos

O fluxo de negociação de orçamentos é **iterativo** e suporta múltiplas rodadas.

### Estados do Orçamento

```
em_analise → aprovado (cliente aprova)
em_analise → rejeitado (cliente rejeita)
em_analise → em_ajuste (cliente sugere ajuste)
em_ajuste  → em_analise (admin reenvia PDF com ajuste)
em_analise → executado (admin marca como executado)
```

### Regras

1. Apenas o admin pode criar orçamentos e fazer upload de PDFs
2. Apenas o cliente pode aprovar, rejeitar ou sugerir ajuste
3. Quando o cliente sugere ajuste, o campo `clientSuggestion` é preenchido e `roundCount` é incrementado
4. O admin vê a sugestão do cliente e pode reenviar um novo PDF (nova rodada)
5. Não há limite de rodadas de negociação
6. Uma vez aprovado ou rejeitado, o orçamento não pode ser reaberto (apenas o admin pode alterar o status manualmente)

---

## 6.4 Fluxo de Solicitação de Material

### Estados da Solicitação

```
pendente → aprovado (cliente aprova)
pendente → rejeitado (cliente rejeita)
aprovado → pago (após upload do comprovante)
```

### Regras

1. Apenas técnicos autenticados podem criar solicitações de material
2. A solicitação deve estar vinculada a uma visita (`visitId`) ou chamado (`ticketId`)
3. O cliente recebe a solicitação e pode aprovar ou rejeitar
4. Após aprovação, o cliente deve realizar o pagamento e fazer upload do comprovante
5. O comprovante é armazenado no S3 e a URL é salva em `receiptUrl`
6. O admin pode visualizar o comprovante na aba Materiais do detalhe do cliente

---

## 6.5 Geração do PDF de Relatório de Preventiva

O PDF é gerado inteiramente no **frontend** (browser) usando a biblioteca `jspdf`.

### Estrutura do PDF

1. **Cabeçalho** (fundo vermelho CJR):
   - Logo CJR (embutida em base64 de `client/src/lib/cjrLogoB64.ts`)
   - Título "RELATÓRIO DE MANUTENÇÃO PREVENTIVA"
   - Data e hora da visita

2. **Dados da Visita:**
   - Nome do cliente e loja
   - Nome do técnico
   - Data agendada e hora

3. **Checklist** (36 itens em 3 colunas):
   - Ícone ✓ (verde) ou ✗ (vermelho) por item
   - Agrupado por categoria (Civil, Hidráulica, Elétrica)

4. **Observações do Técnico**

5. **Evidências Fotográficas:**
   - Grade 2×N com as fotos capturadas durante o checklist
   - Cada foto com legenda do item correspondente

6. **Assinatura Digital:**
   - Imagem da assinatura capturada via `signature_pad`
   - Nome do assinante

7. **Rodapé** (em todas as páginas):
   - Número da página / total de páginas
   - "Costa Júnior — Manutenção Preventiva"

### Processo de Envio

1. PDF gerado como `Uint8Array` via `jspdf`
2. Convertido para base64
3. Enviado ao servidor via `techExecuteVisit` com campos `reportPdfB64` e `reportPdfMime`
4. Servidor salva no S3 via `storagePut()`
5. URL pública salva em `maintenanceVisits.reportPdfUrl`

---

## 6.6 Autenticação e Sessões

### Sessões de Cliente e Técnico

- Token: 48 bytes aleatórios gerados com `crypto.randomBytes(48).toString("hex")`
- Armazenamento: tabelas `clientSessions` e `technicianSessions`
- Duração: 30 dias
- Renovação: não automática (usuário deve fazer login novamente após expiração)
- Invalidação: logout remove o registro da tabela

### Verificação de Sessão

A verificação é feita manualmente em cada procedure que requer autenticação de cliente/técnico:

```typescript
const token = req.cookies?.["cjr_client_session"];
if (!token) return null; // ou throw UNAUTHORIZED

const session = await db.select().from(clientSessions)
  .where(and(eq(clientSessions.token, token), gt(clientSessions.expiresAt, now)))
  .limit(1);

if (!session[0]) return null;
```

---

## 6.7 Códigos de Cliente e Loja

### Geração de Código de Cliente

O código é gerado sequencialmente no formato `CLT-XXXX` onde `XXXX` é um número com 4 dígitos com zeros à esquerda.

**Exemplo:** `CLT-0001`, `CLT-0042`, `CLT-0100`

### Geração de Código de Loja

O código da loja é derivado do código do cliente com sufixo `-LN` onde `N` é o número sequencial da loja.

**Exemplo:** `CLT-0001-L1`, `CLT-0001-L2`, `CLT-0001-L3`

---

## 6.8 Aprovação de Novas Lojas

Quando um cliente adiciona uma nova loja ao seu grupo (mesmo `clientCode`), a loja é criada com `storeApprovalStatus = "pendente_aprovacao"`. O admin precisa aprovar manualmente antes que a loja fique ativa no sistema.

---

## 6.9 Controle de Acesso por Perfil (Usuários Internos)

| Funcionalidade | Admin | Coordenador | Administrativo | Financeiro | Operacional | Comercial |
|---|---|---|---|---|---|---|
| Ver dados financeiros | ✓ | — | — | ✓ | — | ✓ |
| Criar/editar clientes | ✓ | — | — | — | — | — |
| Aprovar materiais | ✓ | — | — | — | — | — |
| Gerenciar técnicos | ✓ | — | — | — | — | — |
| Ver listagem de clientes | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Ver agenda de visitas | ✓ | ✓ | ✓ | ✓ | ✓ | — |
| Gerenciar orçamentos | ✓ | — | — | — | — | — |
| Configurar preços | ✓ | — | — | — | — | — |
| Gerenciar cupons | ✓ | — | — | — | — | — |
| Editar contrato | ✓ | — | — | — | — | — |

---

## 6.10 Cálculo Financeiro do Cliente

A procedure `adminGetClientDetail` calcula o resumo financeiro do cliente:

```typescript
financial: {
  totalMaintenance: sum(monthlyValue * months_active),  // Estimativa de receita de manutenção
  totalMaterials: sum(materialRequests.estimatedValue where status = "aprovado"),
  totalGeneral: totalMaintenance + totalMaterials
}
```

---

## 6.11 Cupons de Desconto

### Regras de Aplicação

1. O cupom deve estar ativo (`isActive = true`)
2. A data atual deve estar entre `validFrom` e `validUntil` (se definidos)
3. `usedCount` deve ser menor que `maxUses` (se definido)
4. O plano do cliente deve estar em `applicablePlans` (se definido)
5. O desconto é aplicado sobre o valor mensal por `discountMonths` meses

**Exemplo:** Cupom de 15% por 3 meses em plano anual de R$ 336/mês:
- Meses com desconto: 3 × R$ 336,00 × 0,85 = R$ 856,80
- Meses sem desconto: 9 × R$ 336,00 = R$ 3.024,00
- Total: R$ 3.880,80 (vs. R$ 4.032,00 sem cupom)
