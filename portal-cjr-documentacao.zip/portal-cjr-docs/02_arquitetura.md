# Portal CJR — Documentação Completa
## Documento 02: Arquitetura Completa

---

## 2.1 Estrutura do Sistema

O Portal CJR é uma aplicação web monolítica com separação clara entre frontend (SPA React) e backend (API Express/tRPC). Ambos rodam no mesmo processo Node.js em desenvolvimento, mas são servidos de forma independente em produção via Vite (frontend estático) e Express (API).

```
┌─────────────────────────────────────────────────────────────────┐
│                        CLIENTE (Browser)                        │
│                                                                 │
│  React 19 SPA (Vite)                                            │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ TecnicoPortal│  │ ClientePortal│  │ AdminManutencao      │  │
│  │  /tecnico    │  │  /cliente    │  │ /admin/manutencao     │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
│                                                                 │
│  tRPC Client (React Query)  →  /api/trpc/*                      │
└───────────────────────────────────────────────────────────────┬─┘
                                                                │ HTTPS
┌───────────────────────────────────────────────────────────────▼─┐
│                     SERVIDOR (Node.js / Express 4)              │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  tRPC Router  /api/trpc                                  │   │
│  │  ├── manutencaoRouter  (server/routers/manutencao.ts)    │   │
│  │  ├── clientAuthRouter  (server/routers/clientAuth.ts)    │   │
│  │  ├── authRouter        (server/routers/auth.ts)          │   │
│  │  └── ... (outros routers do fórum)                       │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │  OAuth Manus │  │  Drizzle ORM │  │  S3 Storage Helper   │  │
│  │  /api/oauth  │  │  (MySQL)     │  │  storagePut()        │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
└───────────────────────────────────────────────────────────────┬─┘
                                                                │
              ┌─────────────────────────────────────────────────┤
              │                                                 │
┌─────────────▼──────┐                          ┌──────────────▼─┐
│  TiDB (MySQL)       │                          │  AWS S3        │
│  (Banco de Dados)   │                          │  (Arquivos)    │
└────────────────────┘                          └────────────────┘
```

---

## 2.2 Tecnologias Utilizadas

### Frontend

| Tecnologia | Versão | Finalidade |
|---|---|---|
| React | 19 | Framework de UI |
| TypeScript | 5.x | Tipagem estática |
| Vite | 6.x | Bundler e dev server |
| Tailwind CSS | 4.x | Estilização utilitária |
| shadcn/ui | — | Componentes de UI (Radix UI) |
| Wouter | — | Roteamento SPA (alternativa ao React Router) |
| @tanstack/react-query | 5.x | Cache e estado de servidor |
| @trpc/react-query | 11.x | Cliente tRPC com React Query |
| jspdf | — | Geração de PDF no browser (relatório de preventiva) |
| signature_pad | — | Assinatura digital no canvas |
| recharts | — | Gráficos (dashboard do cliente) |
| lucide-react | — | Ícones |
| framer-motion | — | Animações |
| date-fns | — | Manipulação de datas |
| react-hook-form | — | Formulários |
| zod | — | Validação de schemas |
| sonner | — | Notificações toast |

### Backend

| Tecnologia | Versão | Finalidade |
|---|---|---|
| Node.js | 22.x | Runtime |
| Express | 4.x | Servidor HTTP |
| tRPC | 11.x | API type-safe (RPC sobre HTTP) |
| Drizzle ORM | — | ORM para MySQL/TiDB |
| mysql2 | — | Driver MySQL |
| bcryptjs | — | Hash de senhas |
| jose | — | JWT (sessões OAuth) |
| cookie-parser | — | Parse de cookies |
| superjson | — | Serialização avançada (Date, Map, etc.) |
| nodemailer / resend | — | Envio de e-mails |
| pdf-lib / pdfkit | — | Manipulação de PDFs no servidor |
| zod | — | Validação de inputs tRPC |
| tsx | — | Execução TypeScript sem compilação |

### Banco de Dados

| Tecnologia | Finalidade |
|---|---|
| TiDB (compatível MySQL) | Banco de dados relacional principal |
| Drizzle Kit | Migrations e push de schema |

### Serviços Externos

| Serviço | Finalidade |
|---|---|
| **Manus OAuth** | Autenticação SSO para usuários internos (colaboradores CJR) |
| **AWS S3** | Armazenamento de arquivos (PDFs, fotos, comprovantes, assinaturas) |
| **Mercado Pago** | Pagamentos online (planos de manutenção e materiais) |
| **Manus LLM API** | IA para o Fórum de Dúvidas |
| **Manus Notification API** | Notificações push para o dono do sistema |

---

## 2.3 Estrutura de Pastas do Projeto

```
forum-cjr/
├── client/                          # Frontend React
│   ├── index.html                   # Entry point HTML
│   ├── public/                      # Assets estáticos (servidos em /)
│   └── src/
│       ├── App.tsx                  # Roteamento principal (Wouter)
│       ├── main.tsx                 # Providers (ThemeProvider, tRPC, QueryClient)
│       ├── index.css                # Variáveis CSS globais (Tailwind 4)
│       ├── const.ts                 # Constantes (getLoginUrl, etc.)
│       ├── components/
│       │   ├── ui/                  # Componentes shadcn/ui (Button, Dialog, etc.)
│       │   ├── DashboardLayout.tsx  # Layout sidebar para painéis internos
│       │   ├── ManutencaoLayout.tsx # Sidebar do módulo de manutenção
│       │   ├── ComercialLayout.tsx  # Sidebar do módulo comercial
│       │   └── AIChatBox.tsx        # Componente de chat com IA
│       ├── contexts/
│       │   └── ThemeContext.tsx     # Contexto de tema (light/dark)
│       ├── hooks/
│       │   ├── useMobile.tsx        # Detecção de dispositivo móvel
│       │   └── usePersistFn.ts      # Hook para funções persistentes
│       ├── lib/
│       │   ├── trpc.ts              # Configuração do cliente tRPC
│       │   ├── utils.ts             # Utilitários (cn, formatters)
│       │   └── cjrLogoB64.ts        # Logo CJR em base64 (para PDF)
│       └── pages/
│           ├── Home.tsx             # Landing page / hub de navegação
│           ├── Chat.tsx             # Fórum de dúvidas com IA
│           ├── TecnicoPortal.tsx    # Portal do técnico (/tecnico)
│           ├── ClientePortal.tsx    # Portal do cliente (/cliente)
│           ├── ClienteLogin.tsx     # Login do cliente (/login-cliente)
│           ├── TecnicoLogin.tsx     # Login do técnico (/login-tecnico)
│           ├── ClienteDefinirSenha.tsx  # Definir senha (token)
│           ├── TecnicoDefinirSenha.tsx  # Definir senha (token)
│           ├── ClienteTrocarSenha.tsx   # Trocar senha (autenticado)
│           ├── TecnicoTrocarSenha.tsx   # Trocar senha (autenticado)
│           ├── admin/
│           │   ├── AdminManutencao.tsx      # Painel admin (/admin/manutencao)
│           │   ├── AdminClienteDetalhe.tsx  # Detalhe do cliente (/admin/manutencao/clientes/:id)
│           │   ├── AdminDashboard.tsx       # Dashboard admin geral
│           │   └── ...                      # Outros painéis admin
│           └── manutencao/
│               ├── DashboardManutencao.tsx  # Dashboard gestão (/manutencao/dashboard)
│               ├── ClientesManutencao.tsx   # Listagem clientes (/manutencao/clientes)
│               ├── ClienteDetalhe.tsx       # Detalhe cliente (/manutencao/clientes/:id)
│               ├── ChamadosManutencao.tsx   # Chamados (/manutencao/chamados)
│               ├── AgendaManutencao.tsx     # Agenda (/manutencao/agenda)
│               ├── TecnicosManutencao.tsx   # Técnicos (/manutencao/tecnicos)
│               ├── PreventivosManutencao.tsx # Preventivos (/manutencao/preventivos)
│               ├── OrcamentosManutencao.tsx # Orçamentos (/manutencao/orcamentos)
│               └── ContratarManutencao.tsx  # Contratação pública (/manutencao/contratar)
│
├── server/                          # Backend Node.js/Express
│   ├── _core/                       # Framework (NÃO editar)
│   │   ├── index.ts                 # Entry point do servidor
│   │   ├── trpc.ts                  # Configuração tRPC (router, procedures)
│   │   ├── context.ts               # Contexto tRPC (req, res, user)
│   │   ├── oauth.ts                 # Manus OAuth handler
│   │   ├── cookies.ts               # Configuração de cookies
│   │   ├── llm.ts                   # Helper para LLM (Manus AI)
│   │   ├── notification.ts          # Helper para notificações
│   │   ├── env.ts                   # Variáveis de ambiente
│   │   └── imageGeneration.ts       # Helper para geração de imagens
│   ├── routers/
│   │   ├── manutencao.ts            # Router principal de manutenção (admin)
│   │   ├── clientAuth.ts            # Router de auth cliente/técnico + portais
│   │   ├── _clientDetail.ts         # Procedure adminGetClientDetail (helper)
│   │   ├── auth.ts                  # Router de autenticação OAuth
│   │   └── ...                      # Outros routers (fórum, comercial, etc.)
│   ├── db.ts                        # Helpers de query do banco
│   ├── storage.ts                   # Helper S3 (storagePut, storageGet)
│   └── routers.ts                   # Agregador de todos os routers
│
├── drizzle/
│   ├── schema.ts                    # Definição de todas as tabelas
│   └── migrations/                  # Arquivos de migração gerados
│
├── shared/                          # Código compartilhado frontend/backend
│   └── types.ts                     # Tipos compartilhados
│
├── package.json                     # Dependências e scripts
├── tsconfig.json                    # Configuração TypeScript
├── vite.config.ts                   # Configuração Vite
└── drizzle.config.ts                # Configuração Drizzle Kit
```

---

## 2.4 Fluxo de Autenticação

O sistema possui **dois sistemas de autenticação independentes**:

### Sistema 1: Manus OAuth (Colaboradores Internos)
- Utilizado por: usuários internos da CJR (admin, coordenador, financeiro, etc.)
- Fluxo: redirecionamento para portal Manus OAuth → callback em `/api/oauth/callback` → cookie de sessão JWT
- Implementado em: `server/_core/oauth.ts`
- Cookie: gerenciado pelo framework `_core`

### Sistema 2: E-mail + Senha (Clientes e Técnicos)
- Utilizado por: clientes (lojistas) e técnicos de manutenção
- Fluxo: POST para `clientAuth.clientLogin` ou `clientAuth.techLogin` → bcrypt hash comparison → cookie de sessão próprio
- Cookies: `cjr_client_session` (clientes) e `cjr_tech_session` (técnicos)
- Duração da sessão: 30 dias
- Token: 48 bytes aleatórios (hex), armazenado em `clientSessions` ou `technicianSessions`
- Implementado em: `server/routers/clientAuth.ts`

### Redefinição de Senha
- Admin gera token de reset (válido por 24h) e envia link por e-mail
- Cliente/técnico acessa `/cliente/definir-senha?token=XXX` ou `/tecnico/definir-senha?token=XXX`
- Senha padrão para técnicos: `tecnico1234` (deve ser trocada no primeiro acesso)

---

## 2.5 Comunicação Frontend ↔ Backend (tRPC)

Todas as chamadas de dados utilizam tRPC sobre HTTP. Não há endpoints REST manuais para funcionalidades de negócio.

```typescript
// Exemplo de query no frontend
const { data } = trpc.manutencao.listClients.useQuery({ search: "loja" });

// Exemplo de mutation no frontend
const createVisit = trpc.manutencao.createVisit.useMutation({
  onSuccess: () => utils.manutencao.listClients.invalidate()
});
```

O tRPC serializa automaticamente tipos complexos (Date, Map, etc.) via superjson. Todos os inputs são validados com Zod no servidor.

---

## 2.6 Armazenamento de Arquivos (S3)

Todos os arquivos binários são armazenados no AWS S3 via helper `storagePut()`. O banco de dados armazena apenas a URL pública e a chave S3.

Tipos de arquivos armazenados:
- **PDFs de relatório de preventiva** (`reportPdfUrl` em `maintenanceVisits`)
- **Assinaturas digitais** (`signatureUrl` em `maintenanceVisits`)
- **Fotos do checklist** (embutidas no PDF via base64, não armazenadas separadamente)
- **PDFs de orçamento** (`fileUrl` em `maintenanceQuotes`)
- **Comprovantes de pagamento** (`receiptUrl` em `materialRequests`)
- **Fotos de chamados** (`photoUrl` em `maintenanceTickets`)
- **Fotos de suporte** (`imageUrl` em `supportTickets`)
- **Documentos institucionais** (`fileUrl` em `institutionalDocuments`)
- **Vídeos de treinamento** (`videoUrl` em `trainingVideos`)
