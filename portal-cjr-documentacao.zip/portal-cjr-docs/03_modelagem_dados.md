# Portal CJR — Documentação Completa
## Documento 03: Modelagem de Dados

---

## 3.1 Visão Geral do Banco de Dados

O banco de dados é MySQL/TiDB gerenciado via Drizzle ORM. O schema está definido em `drizzle/schema.ts`. As tabelas estão organizadas em dois grupos principais: **módulo do fórum/plataforma interna** e **módulo de gestão de manutenção**.

---

## 3.2 Tabelas do Módulo de Manutenção

### `maintenanceClients` — Clientes de Manutenção

Cada registro representa **uma loja** de um cliente. Múltiplas lojas do mesmo grupo compartilham o mesmo `clientCode`.

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `companyName` | VARCHAR(255) | Razão social da empresa |
| `responsibleName` | VARCHAR(255) | Nome do responsável |
| `cnpj` | VARCHAR(20) | CNPJ da empresa |
| `phone` | VARCHAR(30) | Telefone |
| `whatsapp` | VARCHAR(30) | WhatsApp |
| `email` | VARCHAR(320) | E-mail (usado para login) |
| `storeName` | VARCHAR(255) | Nome da loja |
| `shoppingName` | VARCHAR(255) | Nome do shopping |
| `address` | TEXT | Endereço completo |
| `storeArea` | DECIMAL(10,2) | Área da loja em m² |
| `storeType` | ENUM | Tipo: `quiosque`, `ate_40`, `41_80`, `81_120`, `120_250` |
| `planType` | ENUM | Plano: `trimestral`, `semestral`, `anual` |
| `hasEletrica` | BOOLEAN | Serviço elétrico incluído |
| `hasHidraulica` | BOOLEAN | Serviço hidráulico incluído |
| `hasCivil` | BOOLEAN | Serviço civil incluído |
| `monthlyValue` | DECIMAL(10,2) | Valor mensal calculado |
| `totalPlanValue` | DECIMAL(10,2) | Valor total do plano |
| `contractStatus` | ENUM | Status: `ativo`, `pendente`, `inadimplente`, `cancelado`, `suspenso` |
| `contractStartDate` | TIMESTAMP | Data de início do contrato |
| `contractEndDate` | TIMESTAMP | Data de término do contrato |
| `clientCode` | VARCHAR(20) UNIQUE | Código do cliente (ex.: `CLT-0001`) — compartilhado entre lojas do mesmo grupo |
| `storeNumber` | INT | Número sequencial da loja dentro do grupo |
| `storeCode` | VARCHAR(30) UNIQUE | Código único da loja (ex.: `CLT-0001-L2`) |
| `storeApprovalStatus` | ENUM | Aprovação: `pendente_aprovacao`, `aprovado`, `rejeitado` |
| `userId` | INT | FK → `users.id` (opcional, para vinculação OAuth) |
| `passwordHash` | VARCHAR(255) | Hash bcrypt da senha de acesso |
| `mustChangePassword` | BOOLEAN | Obriga troca de senha no próximo login |
| `passwordResetToken` | VARCHAR(128) | Token de redefinição de senha |
| `passwordResetExpires` | TIMESTAMP | Expiração do token de reset |
| `notes` | TEXT | Observações internas |
| `createdById` | INT | FK → `users.id` (quem cadastrou) |
| `createdByName` | VARCHAR(255) | Nome de quem cadastrou |
| `createdAt` | TIMESTAMP | Data de criação |
| `updatedAt` | TIMESTAMP | Data de atualização |

**Regras de negócio:**
- Um cliente pode ter múltiplas lojas; todas compartilham o mesmo `clientCode` e `email`
- O login do cliente usa `email` + `passwordHash` (bcrypt)
- `storeApprovalStatus = "pendente_aprovacao"` quando uma nova loja é adicionada pelo cliente; admin precisa aprovar
- Quando `contractStatus` muda para `"ativo"`, o sistema pode gerar automaticamente o cronograma de preventivas

---

### `maintenanceTechnicians` — Técnicos de Manutenção

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `userId` | INT | FK → `users.id` (opcional) |
| `name` | VARCHAR(255) | Nome completo |
| `phone` | VARCHAR(30) | Telefone |
| `email` | VARCHAR(320) | E-mail (usado para login) |
| `cpf` | VARCHAR(20) | CPF |
| `photoUrl` | TEXT | URL da foto de perfil |
| `specialties` | TEXT | JSON array: `["eletrica","hidraulica","civil"]` |
| `isActive` | BOOLEAN | Técnico ativo no sistema |
| `passwordHash` | VARCHAR(255) | Hash bcrypt da senha |
| `mustChangePassword` | BOOLEAN | Obriga troca de senha |
| `passwordResetToken` | VARCHAR(128) | Token de reset |
| `passwordResetExpires` | TIMESTAMP | Expiração do token |
| `createdAt` | TIMESTAMP | Data de criação |
| `updatedAt` | TIMESTAMP | Data de atualização |

---

### `maintenanceVisits` — Visitas Preventivas/Corretivas

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `clientId` | INT | FK → `maintenanceClients.id` |
| `clientName` | VARCHAR(255) | Nome do cliente (desnormalizado) |
| `technicianId` | INT | FK → `maintenanceTechnicians.id` |
| `technicianName` | VARCHAR(255) | Nome do técnico (desnormalizado) |
| `visitType` | ENUM | Tipo: `preventiva`, `corretiva`, `instalacao`, `vistoria` |
| `scheduledDate` | TIMESTAMP | Data agendada |
| `scheduledTime` | VARCHAR(10) | Hora agendada (ex.: `"09:00"`) |
| `checkInAt` | TIMESTAMP | Hora de entrada do técnico |
| `checkOutAt` | TIMESTAMP | Hora de saída do técnico |
| `status` | ENUM | Status: `agendada`, `em_andamento`, `concluida`, `cancelada`, `reagendada` |
| `checklistItems` | TEXT | JSON array de `{label, done, photoUrl}` — 36 itens |
| `techNotes` | TEXT | Observações do técnico |
| `servicesPerformed` | TEXT | JSON array de serviços realizados |
| `photoBefore` | TEXT | JSON array de URLs de fotos (antes) |
| `photoAfter` | TEXT | JSON array de URLs de fotos (depois) |
| `clientSignatureUrl` | VARCHAR(1024) | URL da assinatura digital do cliente |
| `clientSignatureName` | VARCHAR(255) | Nome de quem assinou |
| `signatureUrl` | VARCHAR(1024) | URL alternativa de assinatura |
| `reportPdfUrl` | VARCHAR(1024) | URL do PDF do relatório gerado |
| `reportPdfKey` | VARCHAR(512) | Chave S3 do PDF |
| `createdById` | INT | FK → `users.id` (quem agendou) |
| `createdAt` | TIMESTAMP | Data de criação |
| `updatedAt` | TIMESTAMP | Data de atualização |

**Regras de negócio:**
- O PDF do relatório é gerado no frontend (jspdf) com logo CJR, dados da visita, fotos do checklist e assinatura digital
- O PDF é enviado ao servidor como base64 e salvo no S3 via `storagePut()`
- Visitas geradas automaticamente pelo cronograma têm `adminNotes` com o texto `"Preventiva N/Total — gerada automaticamente"`

---

### `maintenanceTickets` — Chamados de Manutenção

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `clientId` | INT | FK → `maintenanceClients.id` |
| `title` | VARCHAR(255) | Título do chamado |
| `description` | TEXT | Descrição do problema |
| `category` | ENUM | Categoria: `eletrica`, `hidraulica`, `civil`, `ar_condicionado`, `equipamentos`, `outro` |
| `priority` | ENUM | Prioridade: `baixa`, `media`, `alta`, `urgente` |
| `status` | ENUM | Status: `aberto`, `em_andamento`, `aguardando_material`, `concluido`, `cancelado` |
| `technicianId` | INT | FK → `maintenanceTechnicians.id` |
| `technicianName` | VARCHAR(255) | Nome do técnico (desnormalizado) |
| `visitId` | INT | FK → `maintenanceVisits.id` |
| `location` | VARCHAR(500) | Localização do problema na loja |
| `photoUrl` | VARCHAR(1024) | URL da foto do problema |
| `photoUrls` | TEXT | JSON array de URLs adicionais |
| `resolution` | TEXT | Descrição da resolução |
| `resolvedAt` | TIMESTAMP | Data de resolução |
| `openedById` | INT | FK → usuário que abriu |
| `openedByName` | VARCHAR(255) | Nome de quem abriu |
| `createdAt` | TIMESTAMP | Data de criação |
| `updatedAt` | TIMESTAMP | Data de atualização |

---

### `materialRequests` — Solicitações de Material pelo Técnico

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `ticketId` | INT | FK → `maintenanceTickets.id` (opcional) |
| `visitId` | INT | FK → `maintenanceVisits.id` (opcional) |
| `clientId` | INT | FK → `maintenanceClients.id` |
| `technicianId` | INT | FK → `maintenanceTechnicians.id` |
| `technicianName` | VARCHAR(255) | Nome do técnico |
| `description` | VARCHAR(500) | Descrição do material |
| `estimatedValue` | DECIMAL(10,2) | Valor estimado |
| `status` | ENUM | Status: `pendente`, `aprovado`, `rejeitado`, `pago` |
| `clientApprovedAt` | TIMESTAMP | Data de aprovação pelo cliente |
| `clientRejectedAt` | TIMESTAMP | Data de rejeição pelo cliente |
| `clientNotes` | VARCHAR(500) | Observações do cliente |
| `paymentLink` | VARCHAR(1024) | Link de pagamento Mercado Pago |
| `paymentPreferenceId` | VARCHAR(255) | ID da preferência Mercado Pago |
| `paidAt` | TIMESTAMP | Data de pagamento |
| `receiptUrl` | VARCHAR(1024) | URL do comprovante de pagamento |
| `receiptKey` | VARCHAR(512) | Chave S3 do comprovante |
| `receiptUploadedAt` | TIMESTAMP | Data de upload do comprovante |
| `createdAt` | TIMESTAMP | Data de criação |
| `updatedAt` | TIMESTAMP | Data de atualização |

---

### `maintenanceQuotes` — Orçamentos de Serviços Extras

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `clientId` | INT | FK → `maintenanceClients.id` |
| `title` | VARCHAR(255) | Título do orçamento |
| `description` | TEXT | Descrição do serviço |
| `value` | DECIMAL(10,2) | Valor do orçamento |
| `status` | ENUM | Status: `em_analise`, `em_ajuste`, `aprovado`, `rejeitado`, `executado`, `respondido` |
| `fileUrl` | VARCHAR(1024) | URL do PDF do orçamento |
| `fileKey` | VARCHAR(512) | Chave S3 do PDF |
| `clientFeedback` | TEXT | Feedback do cliente |
| `clientSuggestion` | TEXT | Sugestão de ajuste do cliente |
| `roundCount` | INT | Número de rodadas de negociação (default: 1) |
| `approvedAt` | TIMESTAMP | Data de aprovação |
| `rejectedAt` | TIMESTAMP | Data de rejeição |
| `adminResponse` | TEXT | Resposta do admin ao cliente |
| `deadline` | VARCHAR(100) | Prazo de execução |
| `respondedAt` | TIMESTAMP | Data de resposta do admin |
| `createdById` | INT | FK → `users.id` (admin que criou) |
| `createdAt` | TIMESTAMP | Data de criação |
| `updatedAt` | TIMESTAMP | Data de atualização |

**Regras de negócio do fluxo de negociação:**
1. Admin cria orçamento com PDF → status `"em_analise"`
2. Cliente aprova → status `"aprovado"`, `approvedAt` preenchido
3. Cliente rejeita → status `"rejeitado"`, `rejectedAt` preenchido
4. Cliente sugere ajuste → `clientSuggestion` preenchido, status `"em_ajuste"`, `roundCount` incrementado
5. Admin vê sugestão e reenvia novo PDF → status volta para `"em_analise"`, nova rodada
6. Ciclo se repete até aprovação ou rejeição definitiva

---

### `preventiveConfigs` — Configuração de Preventiva por Loja

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `clientId` | INT UNIQUE | FK → `maintenanceClients.id` |
| `firstPreventiveDate` | TIMESTAMP | Data da primeira preventiva |
| `nextPreventiveDate` | TIMESTAMP | Próxima preventiva calculada |
| `intervalDays` | INT | Intervalo padrão em dias (default: 30) |
| `notes` | TEXT | Observações do admin |
| `updatedByName` | VARCHAR(255) | Nome de quem atualizou |
| `createdAt` | TIMESTAMP | Data de criação |
| `updatedAt` | TIMESTAMP | Data de atualização |

---

### `preventiveDateHistory` — Histórico de Alterações de Data

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `clientId` | INT | FK → `maintenanceClients.id` |
| `previousDate` | TIMESTAMP | Data anterior |
| `newDate` | TIMESTAMP | Nova data |
| `changedByName` | VARCHAR(255) | Nome de quem alterou |
| `reason` | VARCHAR(500) | Motivo da alteração |
| `createdAt` | TIMESTAMP | Data do registro |

---

### `supportTickets` — Chamados de Suporte

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `openedByType` | ENUM | Quem abriu: `tecnico` ou `admin` |
| `openedById` | INT | ID de quem abriu |
| `openedByName` | VARCHAR(255) | Nome de quem abriu |
| `description` | TEXT | Descrição do problema |
| `imageUrl` | VARCHAR(1024) | URL da imagem anexada |
| `imageKey` | VARCHAR(512) | Chave S3 da imagem |
| `status` | ENUM | Status: `aberto`, `em_andamento`, `resolvido`, `fechado` |
| `adminNotes` | TEXT | Notas do admin na resolução |
| `resolvedAt` | TIMESTAMP | Data de resolução |
| `createdAt` | TIMESTAMP | Data de criação |
| `updatedAt` | TIMESTAMP | Data de atualização |

---

### `clientSessions` — Sessões de Cliente

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `clientId` | INT | FK → `maintenanceClients.id` |
| `token` | VARCHAR(255) UNIQUE | Token de sessão (96 hex chars) |
| `expiresAt` | TIMESTAMP | Expiração da sessão |
| `createdAt` | TIMESTAMP | Data de criação |

---

### `technicianSessions` — Sessões de Técnico

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `technicianId` | INT | FK → `maintenanceTechnicians.id` |
| `token` | VARCHAR(255) UNIQUE | Token de sessão |
| `expiresAt` | TIMESTAMP | Expiração da sessão |
| `createdAt` | TIMESTAMP | Data de criação |

---

### `technicianClientLinks` — Vínculo Técnico ↔ Cliente

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `technicianId` | INT | FK → `maintenanceTechnicians.id` |
| `clientId` | INT | FK → `maintenanceClients.id` |
| `createdAt` | TIMESTAMP | Data de criação |

**Regra:** Um técnico só vê as lojas (clientes) às quais está vinculado via esta tabela.

---

### `maintenanceMaterials` — Materiais Aprovados (legado)

Tabela original de materiais (anterior à `materialRequests`). Mantida por compatibilidade.

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `visitId` | INT | FK → `maintenanceVisits.id` |
| `ticketId` | INT | FK → `maintenanceTickets.id` |
| `clientId` | INT | FK → `maintenanceClients.id` |
| `description` | VARCHAR(500) | Descrição |
| `estimatedValue` | DECIMAL(10,2) | Valor estimado |
| `finalValue` | DECIMAL(10,2) | Valor final |
| `adminFee` | DECIMAL(10,2) | Taxa administrativa (~30%) |
| `invoiceUrl` | VARCHAR(1024) | URL da nota fiscal |
| `status` | ENUM | Status: `pendente`, `aprovado`, `reprovado`, `comprado` |
| `approvedById` | INT | FK → `users.id` |
| `approvedAt` | TIMESTAMP | Data de aprovação |
| `requestedById` | INT | FK → `users.id` |
| `createdAt` | TIMESTAMP | Data de criação |
| `updatedAt` | TIMESTAMP | Data de atualização |

---

### `maintenancePriceConfig` — Configuração de Preços

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `storeType` | VARCHAR(50) UNIQUE | Tipo de loja |
| `basePrice` | INT | Preço base (default: 280) |
| `additionalServiceCost` | INT | Custo por serviço adicional (default: 65) |
| `updatedAt` | TIMESTAMP | Data de atualização |
| `updatedByName` | VARCHAR(255) | Nome de quem atualizou |

---

### `maintenanceLeads` — Pré-cadastros / Leads

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `name` | VARCHAR(255) | Nome do responsável |
| `phone` | VARCHAR(30) | Telefone |
| `email` | VARCHAR(320) | E-mail |
| `storeName` | VARCHAR(255) | Nome da loja |
| `shoppingName` | VARCHAR(255) | Nome do shopping |
| `storeType` | ENUM | Tipo de loja |
| `hasEletrica/Hidraulica/Civil` | BOOLEAN | Serviços desejados |
| `planType` | ENUM | Plano escolhido |
| `monthlyValue` | DECIMAL(10,2) | Valor mensal simulado |
| `totalValue` | DECIMAL(10,2) | Valor total simulado |
| `cnpj` | VARCHAR(20) | CNPJ |
| `companyName` | VARCHAR(255) | Razão social |
| `address` | TEXT | Endereço |
| `responsibleName` | VARCHAR(255) | Nome do responsável |
| `whatsapp` | VARCHAR(30) | WhatsApp |
| `leadStep` | INT | Etapa: 1=pré-cadastro, 2=simulação, 3=cadastro, 4=contrato, 5=pagamento |
| `leadStatus` | ENUM | Status: `novo`, `em_andamento`, `convertido`, `perdido`, `contato_feito` |
| `contractAccepted` | BOOLEAN | Contrato aceito |
| `signatureName` | VARCHAR(255) | Nome na assinatura do contrato |
| `paymentPreferenceId` | VARCHAR(255) | ID Mercado Pago |
| `paymentStatus` | ENUM | Status do pagamento |
| `prospectStatus` | ENUM | Status de prospecção manual |
| `clientId` | INT | FK → `maintenanceClients.id` (quando convertido) |
| `notes` | TEXT | Observações |
| `lastContactAt` | TIMESTAMP | Último contato |
| `createdAt` | TIMESTAMP | Data de criação |
| `updatedAt` | TIMESTAMP | Data de atualização |

---

### `maintenanceCoupons` — Cupons de Desconto

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `code` | VARCHAR(50) UNIQUE | Código do cupom |
| `description` | VARCHAR(255) | Descrição |
| `discountPercent` | DECIMAL(5,2) | Percentual de desconto (ex.: 15.00 = 15%) |
| `discountMonths` | INT | Por quantos meses o desconto se aplica |
| `maxUses` | INT | Máximo de usos (null = ilimitado) |
| `usedCount` | INT | Quantidade de usos |
| `validFrom` | TIMESTAMP | Início da validade |
| `validUntil` | TIMESTAMP | Fim da validade |
| `applicablePlans` | VARCHAR(100) | Planos aplicáveis (null = todos) |
| `isActive` | BOOLEAN | Cupom ativo |
| `createdByName` | VARCHAR(255) | Nome de quem criou |
| `createdAt` | TIMESTAMP | Data de criação |
| `updatedAt` | TIMESTAMP | Data de atualização |

---

### `systemSettings` — Configurações do Sistema

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `key` | VARCHAR(100) UNIQUE | Chave da configuração (ex.: `"contract_text"`) |
| `value` | TEXT | Valor da configuração |
| `label` | VARCHAR(255) | Nome amigável para o admin |
| `updatedAt` | TIMESTAMP | Data de atualização |
| `updatedByName` | VARCHAR(255) | Nome de quem atualizou |

---

### `actionLogs` — Logs de Ações do Sistema

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | INT PK | Identificador único |
| `entityType` | VARCHAR(50) | Tipo: `client`, `technician`, `coupon`, `payment`, `lead` |
| `entityId` | INT | ID da entidade |
| `entityCode` | VARCHAR(50) | Código da entidade (ex.: `CLT-0001`) |
| `action` | VARCHAR(100) | Ação: `created`, `updated`, `deleted`, `activated`, `suspended` |
| `description` | TEXT | Descrição da ação |
| `performedById` | INT | FK → `users.id` |
| `performedByName` | VARCHAR(255) | Nome de quem realizou |
| `createdAt` | TIMESTAMP | Data do log |

---

## 3.3 Tabelas do Módulo de Fórum/Plataforma Interna

| Tabela | Descrição |
|---|---|
| `users` | Usuários internos (colaboradores CJR) com autenticação OAuth |
| `documents` | Documentos da base de conhecimento |
| `conversations` | Conversas com a IA |
| `messages` | Mensagens individuais das conversas |
| `knowledgeBase` | Entradas da base de conhecimento |
| `notifications` | Notificações do sistema |
| `deliveryTerms` | Termos de entrega gerados |
| `institutionalDocuments` | Documentos institucionais (onboarding) |
| `meetingMinutes` | Atas de reunião |
| `trainingVideos` | Vídeos de treinamento |
| `trainingPdfs` | PDFs de treinamento |
| `inventoryItems` | Itens de estoque |
| `inventoryMovements` | Movimentações de estoque |
| `equipment` | Equipamentos |
| `prospectClients` | Clientes em prospecção (CRM) |
| `prospectContacts` | Contatos dos prospects |
| `prospectInteractions` | Histórico de interações |
| `prospectTasks` | Tarefas internas |
| `emailTemplates` | Templates de e-mail |
| `followupRules` | Regras de follow-up automático |
| `commercialStandards` | Padrões comerciais |

---

## 3.4 Diagrama de Relacionamentos (Módulo de Manutenção)

```
maintenanceClients (1) ──────────── (N) maintenanceVisits
maintenanceClients (1) ──────────── (N) maintenanceTickets
maintenanceClients (1) ──────────── (N) materialRequests
maintenanceClients (1) ──────────── (N) maintenanceQuotes
maintenanceClients (1) ──────────── (N) maintenanceMaterials
maintenanceClients (1) ──────────── (1) preventiveConfigs
maintenanceClients (1) ──────────── (N) preventiveDateHistory
maintenanceClients (1) ──────────── (N) clientSessions

maintenanceTechnicians (1) ──────── (N) maintenanceVisits
maintenanceTechnicians (1) ──────── (N) materialRequests
maintenanceTechnicians (1) ──────── (N) technicianClientLinks
maintenanceTechnicians (1) ──────── (N) technicianSessions
maintenanceTechnicians (1) ──────── (N) supportTickets

maintenanceVisits (1) ────────────── (N) materialRequests
maintenanceTickets (1) ───────────── (N) materialRequests

users (1) ────────────────────────── (N) maintenanceClients (createdById)
users (1) ────────────────────────── (N) maintenanceVisits (createdById)
users (1) ────────────────────────── (N) maintenanceQuotes (createdById)
```
