# Portal CJR — Documentação Completa
## Documento 05: Documentação das APIs (tRPC)

---

## 5.1 Visão Geral

O Portal CJR utiliza **tRPC v11** para comunicação frontend ↔ backend. Não há endpoints REST manuais para funcionalidades de negócio. Todas as chamadas são feitas via `/api/trpc/{router}.{procedure}`.

**Autenticação:**
- Usuários internos (admin, coordenador, etc.): cookie de sessão OAuth (`manus_session`)
- Clientes: cookie `cjr_client_session`
- Técnicos: cookie `cjr_tech_session`

**Tipos de procedure:**
- `publicProcedure` — Sem autenticação requerida
- `protectedProcedure` — Requer usuário interno autenticado (OAuth)
- Procedures de cliente/técnico verificam manualmente o cookie de sessão

---

## 5.2 Router: `manutencao` (Administração)

Base: `trpc.manutencao.*`

### `calcPrice` — Calcular Preço do Plano
**Tipo:** Query (público)  
**Descrição:** Calcula o valor mensal e total de um plano com base no tipo de loja e serviços.

**Input:**
```typescript
{
  storeType: string;    // "quiosque" | "ate_40" | "41_80" | "81_120" | "120_250"
  planType: string;     // "trimestral" | "semestral" | "anual"
  hasEletrica: boolean;
  hasHidraulica: boolean;
  hasCivil: boolean;
}
```

**Output:**
```typescript
{
  monthly: number;   // Valor mensal com desconto do plano
  total: number;     // Valor total do plano
  savings: number;   // Economia em relação ao plano trimestral
}
```

---

### `listClients` — Listar Clientes
**Tipo:** Query (protegido)  
**Descrição:** Retorna todos os clientes de manutenção com filtros opcionais.

**Input:**
```typescript
{
  search?: string;   // Busca por nome da empresa, loja ou responsável
  status?: string;   // Filtro por contractStatus
}
```

**Output:** Array de `MaintenanceClient`

---

### `getClient` — Obter Cliente
**Tipo:** Query (protegido)  
**Input:** `{ id: number }`  
**Output:** `MaintenanceClient | null`

---

### `createClient` — Criar Cliente
**Tipo:** Mutation (protegido, admin)  
**Descrição:** Cria um novo cliente de manutenção com código único gerado automaticamente.

**Input:**
```typescript
{
  companyName: string;
  responsibleName: string;
  email: string;
  phone?: string;
  whatsapp?: string;
  cnpj?: string;
  storeName: string;
  shoppingName?: string;
  address?: string;
  storeType: string;
  planType: string;
  hasEletrica: boolean;
  hasHidraulica: boolean;
  hasCivil: boolean;
  contractStatus?: string;
  notes?: string;
}
```

**Output:** `{ id: number; clientCode: string }`

---

### `updateClient` — Atualizar Cliente
**Tipo:** Mutation (protegido)  
**Input:** `{ id: number; ...campos opcionais }`  
**Output:** `{ ok: true }`

---

### `createVisit` — Agendar Visita
**Tipo:** Mutation (protegido)  
**Descrição:** Cria uma nova visita preventiva ou corretiva.

**Input:**
```typescript
{
  clientId: number;
  technicianId?: number;
  visitType?: string;       // "preventiva" | "corretiva" | "instalacao" | "vistoria"
  scheduledDate: string;    // ISO date string
  scheduledTime?: string;   // "HH:MM"
  notes?: string;
}
```

**Output:** `{ id: number }`

---

### `generatePreventiveSchedule` — Gerar Cronograma Automático
**Tipo:** Mutation (protegido, admin)  
**Descrição:** Gera automaticamente todas as visitas preventivas do plano a partir de uma data inicial.

**Input:**
```typescript
{
  clientId: number;
  startDate?: string;   // ISO date, default = hoje
}
```

**Lógica:**
- Plano trimestral: 3 visitas
- Plano semestral: 6 visitas
- Plano anual: 12 visitas
- 1ª visita: data informada
- 2ª visita: +10 dias
- Demais: +30 dias da anterior

**Output:** `{ success: true; count: number }`

---

### `approveMaterial` — Aprovar/Reprovar Material
**Tipo:** Mutation (protegido)  
**Input:**
```typescript
{
  materialId: number;
  action: "aprovado" | "reprovado";
  notes?: string;
}
```
**Output:** `{ ok: true }`

---

### `adminUploadQuote` — Criar Orçamento com PDF
**Tipo:** Mutation (protegido, admin)  
**Descrição:** Cria um novo orçamento para um cliente e faz upload do PDF para o S3.

**Input:**
```typescript
{
  clientId: number;
  title: string;
  description?: string;
  value?: number;
  fileBase64?: string;   // PDF em base64
  fileMime?: string;     // "application/pdf"
}
```
**Output:** `{ id: number }`

---

### `getAdminDashboard` — Dashboard Administrativo
**Tipo:** Query (protegido)  
**Output:**
```typescript
{
  totalClients: number;
  activeClients: number;
  totalVisits: number;
  visitsThisMonth: number;
  openTickets: number;
  monthlyRevenue: number;
}
```

---

### `getSetting` — Obter Configuração do Sistema
**Tipo:** Query (público)  
**Input:** `{ key: string }`  
**Output:** `{ value: string } | null`

---

### `updateSetting` — Atualizar Configuração do Sistema
**Tipo:** Mutation (protegido, admin)  
**Input:** `{ key: string; value: string }`  
**Output:** `{ ok: true }`

---

### `adminGetClientDetail` — Detalhe Consolidado do Cliente
**Tipo:** Query (protegido)  
**Input:** `{ clientId: number }`  
**Output:**
```typescript
{
  client: MaintenanceClient;
  stores: MaintenanceClient[];          // Todas as lojas do mesmo clientCode
  visits: MaintenanceVisit[];
  materials: MaintenanceMaterial[];
  quotes: MaintenanceQuote[];
  preventiveConfig: PreventiveConfig | null;
  reports: MaintenanceVisit[];          // Visitas com reportPdfUrl
  financial: {
    totalMaintenance: number;
    totalMaterials: number;
    totalGeneral: number;
  };
}
```

---

### `listTechnicians` — Listar Técnicos
**Tipo:** Query (protegido)  
**Output:** Array de `MaintenanceTechnician`

---

### `createTechnician` — Criar Técnico
**Tipo:** Mutation (protegido, admin)  
**Input:** `{ name, email, phone?, cpf?, specialties? }`  
**Output:** `{ id: number }`

---

### `linkTechnicianToClient` — Vincular Técnico ao Cliente
**Tipo:** Mutation (protegido, admin)  
**Input:** `{ technicianId: number; clientId: number }`  
**Output:** `{ ok: true }`

---

### `listSupportTickets` — Listar Chamados de Suporte
**Tipo:** Query (protegido)  
**Output:** Array de `SupportTicket`

---

### `respondSupportTicket` — Responder Chamado de Suporte
**Tipo:** Mutation (protegido, admin)  
**Input:** `{ ticketId: number; notes: string; status: string }`  
**Output:** `{ ok: true }`

---

## 5.3 Router: `clientAuth` (Portais de Cliente e Técnico)

Base: `trpc.clientAuth.*`

### `clientLogin` — Login do Cliente
**Tipo:** Mutation (público)  
**Input:** `{ email: string; password: string }`  
**Output:** `{ ok: true; clientCode: string; mustChangePassword: boolean }`  
**Efeito colateral:** Define cookie `cjr_client_session`

---

### `clientLogout` — Logout do Cliente
**Tipo:** Mutation (público)  
**Output:** `{ ok: true }`  
**Efeito colateral:** Remove cookie `cjr_client_session`

---

### `clientMe` — Dados do Cliente Logado
**Tipo:** Query (público — verifica cookie internamente)  
**Output:**
```typescript
{
  id: number;
  clientCode: string;
  companyName: string;
  responsibleName: string;
  email: string;
  mustChangePassword: boolean;
  stores: Array<{
    id: number;
    storeName: string;
    storeCode: string;
    address: string;
    contractStatus: string;
    storeApprovalStatus: string;
    planType: string;
    hasEletrica: boolean;
    hasHidraulica: boolean;
    hasCivil: boolean;
    monthlyValue: string;
    contractStartDate: Date;
    contractEndDate: Date;
  }>;
} | null
```

---

### `clientSetPassword` — Definir Senha (Token)
**Tipo:** Mutation (público)  
**Input:** `{ token: string; password: string }`  
**Output:** `{ ok: true }`

---

### `clientChangePassword` — Trocar Senha (Autenticado)
**Tipo:** Mutation (público — verifica cookie)  
**Input:** `{ currentPassword: string; newPassword: string }`  
**Output:** `{ ok: true }`

---

### `clientDashboardStats` — Estatísticas do Dashboard
**Tipo:** Query (público — verifica cookie)  
**Output:**
```typescript
{
  totalTickets: number;
  openTickets: number;
  totalVisits: number;
  ticketsByCategory: Array<{ category: string; count: number }>;
}
```

---

### `clientListTickets` — Listar Chamados do Cliente
**Tipo:** Query (público — verifica cookie)  
**Input:** `{ storeId?: number }`  
**Output:** Array de `MaintenanceTicket`

---

### `clientCreateTicket` — Criar Chamado
**Tipo:** Mutation (público — verifica cookie)  
**Input:**
```typescript
{
  storeId: number;
  title: string;
  description: string;
  category: string;
  priority?: string;
  location?: string;
  photoBase64?: string;
  photoMime?: string;
}
```
**Output:** `{ id: number }`

---

### `clientListVisits` — Listar Visitas
**Tipo:** Query (público — verifica cookie)  
**Input:** `{ storeId?: number }`  
**Output:** Array de `MaintenanceVisit`

---

### `clientListQuotes` — Listar Orçamentos
**Tipo:** Query (público — verifica cookie)  
**Output:** Array de `MaintenanceQuote`

---

### `clientRespondQuote` — Responder Orçamento
**Tipo:** Mutation (público — verifica cookie)  
**Input:**
```typescript
{
  quoteId: number;
  action: "aprovado" | "rejeitado" | "ajuste";
  feedback?: string;
  suggestion?: string;   // Obrigatório se action = "ajuste"
}
```
**Output:** `{ ok: true }`

---

### `clientListMaterialRequests` — Listar Solicitações de Material
**Tipo:** Query (público — verifica cookie)  
**Output:** Array de `MaterialRequest`

---

### `clientRespondMaterialRequest` — Aprovar/Rejeitar Material
**Tipo:** Mutation (público — verifica cookie)  
**Input:** `{ requestId: number; action: "aprovado" | "rejeitado"; notes?: string }`  
**Output:** `{ ok: true }`

---

### `clientUploadMaterialReceipt` — Enviar Comprovante de Pagamento
**Tipo:** Mutation (público — verifica cookie)  
**Input:**
```typescript
{
  materialRequestId: number;
  receiptBase64: string;   // Imagem ou PDF em base64
  receiptMime: string;     // "image/jpeg" | "image/png" | "application/pdf"
}
```
**Output:** `{ ok: true; receiptUrl: string }`

---

### `clientUpdateProfile` — Atualizar Perfil
**Tipo:** Mutation (público — verifica cookie)  
**Input:** `{ email?: string; phone?: string; whatsapp?: string }`  
**Output:** `{ ok: true }`

---

### `techLogin` — Login do Técnico
**Tipo:** Mutation (público)  
**Input:** `{ email: string; password: string }`  
**Output:** `{ ok: true; technicianId: number; mustChangePassword: boolean }`  
**Efeito colateral:** Define cookie `cjr_tech_session`

---

### `techLogout` — Logout do Técnico
**Tipo:** Mutation (público)  
**Output:** `{ ok: true }`

---

### `techMe` — Dados do Técnico Logado
**Tipo:** Query (público — verifica cookie)  
**Output:** `{ id, name, email, specialties, linkedClients: [...] } | null`

---

### `techExecuteVisit` — Executar Visita (Enviar Relatório)
**Tipo:** Mutation (público — verifica cookie)  
**Descrição:** Finaliza uma visita preventiva com checklist, assinatura e PDF do relatório.

**Input:**
```typescript
{
  visitId: number;
  checklistItems: Array<{ label: string; done: boolean; photoB64?: string }>;
  techNotes?: string;
  signatureB64: string;       // Assinatura digital em base64 (PNG)
  signatureName: string;      // Nome do assinante
  reportPdfB64: string;       // PDF completo em base64
  reportPdfMime: string;      // "application/pdf"
  servicesPerformed?: string[];
}
```
**Output:** `{ ok: true; reportPdfUrl: string }`

---

### `techRequestMaterial` — Solicitar Material
**Tipo:** Mutation (público — verifica cookie)  
**Input:**
```typescript
{
  visitId?: number;
  ticketId?: number;
  clientId: number;
  description: string;
  estimatedValue: number;
}
```
**Output:** `{ id: number }`

---

### `techListMaterialRequests` — Listar Solicitações de Material (Técnico)
**Tipo:** Query (público — verifica cookie)  
**Output:** Array de `MaterialRequest`

---

### `techCreateSupportTicket` — Abrir Chamado de Suporte
**Tipo:** Mutation (público — verifica cookie)  
**Input:**
```typescript
{
  description: string;
  imageBase64?: string;
  imageMime?: string;
}
```
**Output:** `{ id: number }`

---

### `adminListQuotes` — Listar Todos os Orçamentos (Admin)
**Tipo:** Query (protegido)  
**Input:** `{ status?: string; search?: string }`  
**Output:** Array de `MaintenanceQuote` com dados do cliente

---

### `adminRespondQuote` — Responder Orçamento (Admin)
**Tipo:** Mutation (protegido, admin)  
**Input:**
```typescript
{
  quoteId: number;
  status: string;
  adminResponse?: string;
  value?: number;
  deadline?: string;
  fileBase64?: string;    // Novo PDF em base64 (para reenvio após ajuste)
  fileMime?: string;
}
```
**Output:** `{ ok: true }`

---

### `adminGenerateClientPasswordReset` — Gerar Link de Reset de Senha
**Tipo:** Mutation (protegido, admin)  
**Input:** `{ clientId: number }`  
**Output:** `{ resetUrl: string }`  
**Validade do token:** 24 horas

---

### `adminGenerateTechPasswordReset` — Gerar Link de Reset de Senha (Técnico)
**Tipo:** Mutation (protegido, admin)  
**Input:** `{ technicianId: number }`  
**Output:** `{ resetUrl: string }`

---

## 5.4 Formato de Chamada tRPC

### Query (GET)
```
GET /api/trpc/manutencao.listClients?input={"search":"loja"}
```

### Mutation (POST)
```
POST /api/trpc/clientAuth.clientLogin
Content-Type: application/json

{"json": {"email": "cliente@email.com", "password": "senha123"}}
```

### Batch (múltiplas chamadas)
O cliente tRPC agrupa automaticamente múltiplas queries em uma única requisição HTTP:
```
GET /api/trpc/manutencao.listClients,clientAuth.clientMe?batch=1&input=...
```

---

## 5.5 Tratamento de Erros

O tRPC retorna erros padronizados com código HTTP e mensagem:

| Código tRPC | HTTP | Descrição |
|---|---|---|
| `UNAUTHORIZED` | 401 | Sessão inválida ou expirada |
| `FORBIDDEN` | 403 | Permissão insuficiente |
| `NOT_FOUND` | 404 | Recurso não encontrado |
| `BAD_REQUEST` | 400 | Input inválido (Zod validation) |
| `INTERNAL_SERVER_ERROR` | 500 | Erro interno do servidor |

Exemplo de resposta de erro:
```json
{
  "error": {
    "message": "E-mail ou senha inválidos.",
    "code": -32600,
    "data": {
      "code": "BAD_REQUEST",
      "httpStatus": 400
    }
  }
}
```
