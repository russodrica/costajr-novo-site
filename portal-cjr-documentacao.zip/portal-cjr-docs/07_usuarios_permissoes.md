# Portal CJR — Documentação Completa
## Documento 07: Estrutura de Usuários e Permissões

---

## 7.1 Perfis de Acesso

O sistema possui **dois sistemas de identidade independentes**:

### Sistema 1: Usuários Internos (Colaboradores CJR)
Autenticados via Manus OAuth. Armazenados na tabela `users`.

| Perfil (`role`) | Descrição | Acesso Principal |
|---|---|---|
| `admin` | Administrador total do sistema | Todos os módulos, todas as ações |
| `coordenador` | Coordenador de operações | Módulos operacionais, sem financeiro |
| `administrativo` | Equipe administrativa | Documentos, fórum, treinamentos |
| `financeiro` | Equipe financeira | Dados financeiros, relatórios |
| `operacional` | Equipe operacional | Chamados, agenda, visitas |
| `comercial` | Equipe comercial | CRM de prospecção, dados comerciais |

### Sistema 2: Usuários Externos (Clientes e Técnicos)
Autenticados via e-mail + senha própria. Armazenados em `maintenanceClients` e `maintenanceTechnicians`.

| Perfil | Tabela | Cookie de Sessão | Portal |
|---|---|---|---|
| Cliente (Lojista) | `maintenanceClients` | `cjr_client_session` | `/cliente` |
| Técnico | `maintenanceTechnicians` | `cjr_tech_session` | `/tecnico` |

---

## 7.2 Permissões Detalhadas por Módulo

### Módulo de Manutenção — Painel Admin (`/admin/manutencao`)

| Ação | Admin | Financeiro | Comercial | Outros |
|---|---|---|---|---|
| Ver aba Dashboard | ✓ | ✓ | ✓ | — |
| Ver aba Clientes | ✓ | ✓ | ✓ | — |
| Criar/editar cliente | ✓ | — | — | — |
| Ver dados financeiros do cliente | ✓ | ✓ | ✓ | — |
| Ver aba Leads | ✓ | — | ✓ | — |
| Converter lead em cliente | ✓ | — | — | — |
| Ver aba Técnicos | ✓ | — | — | — |
| Criar/editar técnico | ✓ | — | — | — |
| Vincular técnico a cliente | ✓ | — | — | — |
| Ver aba Preços | ✓ | — | — | — |
| Editar tabela de preços | ✓ | — | — | — |
| Ver aba Cupons | ✓ | — | — | — |
| Criar/editar cupons | ✓ | — | — | — |
| Ver aba Contrato | ✓ | — | — | — |
| Editar texto do contrato | ✓ | — | — | — |
| Ver aba Orçamentos | ✓ | — | — | — |
| Criar/responder orçamentos | ✓ | — | — | — |
| Ver aba Suporte | ✓ | — | — | — |
| Responder chamados de suporte | ✓ | — | — | — |
| Gerar link de reset de senha | ✓ | — | — | — |
| Gerar cronograma automático | ✓ | — | — | — |
| Aprovar/reprovar materiais | ✓ | — | — | — |
| Aprovar novas lojas | ✓ | — | — | — |
| Exportar CSV | ✓ | ✓ | — | — |

### Módulo de Manutenção — Gestão (`/manutencao/*`)

| Ação | Admin | Coordenador | Administrativo | Financeiro | Operacional | Comercial |
|---|---|---|---|---|---|---|
| Dashboard | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Listar clientes | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Ver detalhe do cliente | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Chamados | ✓ | ✓ | ✓ | ✓ | ✓ | — |
| Agenda de visitas | ✓ | ✓ | ✓ | ✓ | ✓ | — |
| Técnicos | ✓ | — | — | — | — | — |
| Preventivos | ✓ | — | — | — | — | — |
| Orçamentos | ✓ | — | — | — | — | — |

### Portal do Cliente (`/cliente`)

O cliente tem acesso **apenas aos dados das suas próprias lojas** (identificadas pelo `clientCode`).

| Ação | Cliente |
|---|---|
| Ver dashboard | ✓ |
| Ver chamados das suas lojas | ✓ |
| Criar chamado | ✓ |
| Ver preventivas das suas lojas | ✓ |
| Ver PDF de relatório | ✓ |
| Aprovar/rejeitar material | ✓ |
| Enviar comprovante de pagamento | ✓ |
| Ver orçamentos | ✓ |
| Aprovar/rejeitar/sugerir ajuste em orçamento | ✓ |
| Ver contrato | ✓ |
| Editar perfil (e-mail, telefone) | ✓ |
| Ver dados de outros clientes | ✗ |
| Criar visitas | ✗ |
| Criar orçamentos | ✗ |

### Portal do Técnico (`/tecnico`)

O técnico tem acesso **apenas às lojas às quais está vinculado** via `technicianClientLinks`.

| Ação | Técnico |
|---|---|
| Ver lojas vinculadas | ✓ |
| Ver agenda de visitas | ✓ |
| Executar visita (checklist + assinatura + PDF) | ✓ |
| Ver chamados atribuídos | ✓ |
| Executar chamado | ✓ |
| Solicitar material | ✓ |
| Ver status das solicitações de material | ✓ |
| Abrir chamado de suporte | ✓ |
| Ver lojas de outros técnicos | ✗ |
| Aprovar materiais | ✗ |
| Criar orçamentos | ✗ |
| Ver dados financeiros | ✗ |

---

## 7.3 Verificação de Permissões no Backend

### Usuários Internos (OAuth)

```typescript
// Verificação de role admin
if (ctx.user.role !== "admin") {
  throw new TRPCError({ code: "FORBIDDEN" });
}

// Verificação de acesso financeiro
const hasFinancialAccess = ["admin", "financeiro", "comercial"].includes(ctx.user.role);
```

### Clientes (Cookie de Sessão)

```typescript
// Verificação de sessão de cliente
const token = req.cookies?.["cjr_client_session"];
if (!token) return null;

const session = await db.select().from(clientSessions)
  .where(and(eq(clientSessions.token, token), gt(clientSessions.expiresAt, now)))
  .limit(1);

if (!session[0]) throw new TRPCError({ code: "UNAUTHORIZED" });

// Verificação de propriedade (cliente só vê suas lojas)
const client = await db.select().from(maintenanceClients)
  .where(eq(maintenanceClients.id, session[0].clientId))
  .limit(1);

// Busca todas as lojas do mesmo clientCode
const allStores = await db.select().from(maintenanceClients)
  .where(eq(maintenanceClients.clientCode, client[0].clientCode));

const storeIds = allStores.map(s => s.id);
// Filtra dados apenas para essas lojas
```

### Técnicos (Cookie de Sessão)

```typescript
// Verificação de sessão de técnico
const token = req.cookies?.["cjr_tech_session"];
// ... similar ao cliente

// Verificação de vínculo com cliente
const links = await db.select().from(technicianClientLinks)
  .where(eq(technicianClientLinks.technicianId, technicianId));

const linkedClientIds = links.map(l => l.clientId);
// Técnico só pode ver/executar visitas de clientes vinculados
```

---

## 7.4 Fluxo de Criação de Acesso

### Para Novo Cliente

1. Admin cria o cliente em `/admin/manutencao` (aba Clientes)
2. Sistema gera `clientCode` automaticamente (ex.: `CLT-0042`)
3. Admin clica em "Gerar Link de Senha" → sistema cria token de reset (24h)
4. Admin envia o link por e-mail ou WhatsApp para o cliente
5. Cliente acessa `/cliente/definir-senha?token=XXX` e define sua senha
6. Cliente pode fazer login em `/login-cliente`

### Para Novo Técnico

1. Admin cria o técnico em `/admin/manutencao` (aba Técnicos)
2. Senha padrão: `tecnico1234` (com `mustChangePassword = true`)
3. Admin vincula o técnico às lojas que ele atenderá
4. Técnico faz login em `/login-tecnico` com e-mail e senha padrão
5. Sistema redireciona para `/tecnico/trocar-senha` na primeira sessão

### Para Novo Colaborador Interno

1. Colaborador acessa o portal e faz login via Manus OAuth
2. Conta criada com `approvalStatus = "pending"` e `role = "operacional"` (padrão)
3. Admin acessa `/admin/users` e aprova o colaborador
4. Admin pode alterar o `role` conforme a função do colaborador

---

## 7.5 Restrições de Segurança

1. **Isolamento de dados:** Clientes não podem acessar dados de outros clientes. A verificação é feita via `clientCode` em todas as queries do portal do cliente.

2. **Isolamento de técnicos:** Técnicos só veem lojas vinculadas via `technicianClientLinks`. Não há acesso a dados de clientes não vinculados.

3. **Senhas:** Armazenadas com bcrypt (salt rounds: 12). Nunca armazenadas em texto plano.

4. **Tokens de reset:** Gerados com `crypto.randomBytes(32)`, válidos por 24 horas, invalidados após uso.

5. **Sessões:** Tokens de 96 caracteres hex (48 bytes), armazenados no banco com expiração. Invalidados no logout.

6. **Acesso admin:** Verificado explicitamente em cada procedure sensível via `ctx.user.role !== "admin"`.

7. **Arquivos S3:** Chaves geradas com sufixo aleatório para evitar enumeração. Bucket público (URLs diretas sem assinatura).
