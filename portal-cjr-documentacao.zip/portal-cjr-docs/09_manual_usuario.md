# Portal CJR — Documentação Completa
## Documento 09: Manual do Usuário

---

## 9.1 Manual do Cliente (Lojista)

### Primeiro Acesso

1. Você receberá um link por e-mail ou WhatsApp da equipe CJR no formato:
   `https://portalcjr.vip/cliente/definir-senha?token=XXXXXXXX`

2. Acesse o link e defina sua senha (mínimo 6 caracteres).

3. Após definir a senha, acesse o portal em:
   `https://portalcjr.vip/login-cliente`

4. Insira seu e-mail e a senha que você acabou de definir.

---

### Navegando pelo Portal

Após o login, você verá o menu lateral com as seguintes seções:

**Dashboard:** Visão geral com gráfico de chamados por tipo no último ano e contadores de chamados abertos e preventivas realizadas.

**Lojas:** Aqui você gerencia todas as suas lojas. Se você tiver mais de uma loja no mesmo grupo, todas aparecerão aqui.

**Plano:** Informações sobre o seu plano de manutenção (tipo, valor, serviços incluídos, vigência).

**Termo:** Acesso ao contrato de adesão assinado.

---

### Abrindo um Chamado de Manutenção

1. No menu lateral, clique em **Lojas**
2. Selecione a loja onde ocorreu o problema
3. Clique na aba **Chamados**
4. Clique no botão **+ Novo Chamado**
5. Preencha os campos:
   - **Título:** Resumo do problema (ex.: "Torneira com vazamento")
   - **Descrição:** Detalhes do problema
   - **Categoria:** Elétrica, Hidráulica, Civil, Ar-condicionado, Equipamentos ou Outro
   - **Prioridade:** Baixa, Média, Alta ou Urgente
   - **Localização:** Onde na loja está o problema (ex.: "Banheiro feminino")
   - **Foto:** Tire uma foto do problema (opcional, mas recomendado)
6. Clique em **Enviar**

---

### Aprovando uma Solicitação de Material

Quando o técnico precisar de materiais para realizar o serviço, você receberá uma solicitação:

1. Acesse **Lojas** → selecione a loja → aba **Materiais**
2. Você verá a solicitação com descrição e valor estimado
3. Clique em **✓ Aprovar** para autorizar a compra, ou **✕ Rejeitar** para recusar
4. Se aprovado, realize o pagamento pelo link disponível
5. Após o pagamento, clique em **📤 Enviar Comprovante**
6. Selecione a imagem ou PDF do comprovante e clique em **Confirmar envio**

---

### Respondendo a um Orçamento

Quando a CJR enviar um orçamento para um serviço extra:

1. Acesse **Lojas** → selecione a loja → aba **Orçamentos**
2. Clique em **Ver PDF** para visualizar o orçamento detalhado
3. Você tem três opções:
   - **✓ Aprovar:** Aceita o orçamento como está
   - **✕ Rejeitar:** Recusa o orçamento (informe o motivo)
   - **💬 Sugerir Ajuste:** Envie uma sugestão de modificação para a CJR revisar

Se você sugerir um ajuste, a CJR analisará sua sugestão e poderá enviar um novo orçamento revisado.

---

### Acompanhando Visitas Preventivas

1. Acesse **Lojas** → selecione a loja → aba **Preventivas**
2. Você verá o histórico de todas as visitas preventivas
3. Para visitas concluídas, clique em **📄 Ver Relatório** para baixar o PDF do relatório
4. O card no topo mostra a data da próxima preventiva agendada

---

### Editando seu Perfil

1. Clique no ícone de perfil no canto superior direito
2. Você pode atualizar seu e-mail e telefone
3. Clique em **Salvar** para confirmar as alterações

---

## 9.2 Manual do Técnico

### Primeiro Acesso

1. Acesse `https://portalcjr.vip/login-tecnico`
2. Use o e-mail cadastrado pelo administrador e a senha padrão: `tecnico1234`
3. No primeiro login, você será redirecionado para trocar a senha
4. Defina uma nova senha segura

---

### Visualizando suas Lojas

Na aba **Lojas**, você verá todas as lojas que estão vinculadas a você. Para cada loja, você pode acessar:
- **Chamados:** Chamados atribuídos a você nessa loja
- **Preventivas:** Histórico de visitas preventivas
- **Checklist:** Checklist da última preventiva
- **Materiais:** Solicitações de material

---

### Verificando a Agenda

Na aba **Agenda**, você verá todas as visitas agendadas para você. O badge colorido indica a urgência da próxima preventiva:
- 🟢 Verde: mais de 7 dias
- 🟡 Amarelo: 3 a 7 dias
- 🔴 Vermelho: menos de 3 dias ou atrasada

Clique no badge para ver todas as lojas com preventiva no mesmo dia.

---

### Executando uma Visita Preventiva

**Passo 1: Iniciar a visita**
1. Acesse a aba **Agenda** ou **Lojas** → **Preventivas**
2. Localize a visita agendada e clique em **Iniciar Visita**

**Passo 2: Preencher o Checklist**
O checklist possui 36 itens divididos em três grupos:

- **CIVIL (12 itens):** Pisos, paredes, portas, impermeabilização, pintura, etc.
- **HIDRÁULICA (12 itens):** Torneiras, vasos, caixas d'água, bombas, etc.
- **ELÉTRICA (12 itens):** Quadro elétrico, disjuntores, tomadas, iluminação, etc.

Para cada item:
1. Marque o checkbox se o item foi verificado e está OK
2. Clique no ícone de câmera 📷 para tirar uma foto como evidência
3. A foto é obrigatória para itens marcados como concluídos

**Passo 3: Observações**
Preencha o campo de observações com qualquer informação relevante sobre a visita.

**Passo 4: Assinatura Digital**
1. Solicite ao responsável da loja que assine na tela
2. O responsável desenha a assinatura com o dedo ou mouse
3. Preencha o nome do assinante
4. Clique em **Confirmar Assinatura**

**Passo 5: Gerar Relatório**
1. Clique em **Gerar Relatório e Finalizar**
2. O sistema gerará automaticamente um PDF com:
   - Logo CJR e dados da visita
   - Checklist completo com status de cada item
   - Fotos das evidências
   - Assinatura digital
3. O PDF é enviado ao servidor e fica disponível para o cliente

---

### Executando um Chamado Corretivo

1. Acesse a aba **Chamados**
2. Localize o chamado atribuído a você
3. Clique em **Executar**
4. Atualize o status conforme o andamento:
   - `Em Andamento` — quando iniciar o serviço
   - `Aguardando Material` — se precisar de materiais
   - `Concluído` — quando finalizar
5. Ao concluir, é obrigatório tirar uma foto do serviço realizado
6. Preencha a descrição da resolução

---

### Solicitando Material

Se você precisar de materiais durante uma visita ou chamado:

1. Clique em **Solicitar Material** (disponível na execução de chamados e visitas)
2. Preencha:
   - **Descrição:** O que precisa (ex.: "Registro de gaveta 1/2 polegada")
   - **Valor Estimado:** Custo aproximado do material
3. Clique em **Enviar Solicitação**
4. O cliente receberá a solicitação e poderá aprovar ou rejeitar
5. Você pode acompanhar o status na aba **Materiais** da loja

---

### Abrindo um Chamado de Suporte

Se você tiver algum problema técnico ou precisar de suporte da equipe CJR:

1. Acesse a aba **Suporte** (ícone de headset no menu)
2. Clique em **+ Novo Chamado de Suporte**
3. Descreva o problema detalhadamente
4. Anexe uma foto se necessário
5. Clique em **Enviar**
6. A equipe CJR responderá em breve

---

## 9.3 Manual do Administrador CJR

### Acessando o Painel Administrativo

1. Acesse `https://portalcjr.vip` e faça login com sua conta Manus
2. No menu principal, acesse **Admin** → **Manutenção**
3. Você verá o painel administrativo completo em `/admin/manutencao`

---

### Cadastrando um Novo Cliente

1. Acesse a aba **Clientes**
2. Clique em **+ Novo Cliente**
3. Preencha todos os dados:
   - Dados da empresa (razão social, CNPJ, responsável)
   - Dados da loja (nome, shopping, endereço, tipo, área)
   - Serviços incluídos (Elétrica, Hidráulica, Civil)
   - Tipo de plano (Trimestral, Semestral, Anual)
4. O sistema calculará automaticamente o valor mensal e total
5. Clique em **Salvar**
6. O sistema gerará um código único para o cliente (ex.: `CLT-0042`)

**Após o cadastro:**
1. Clique em **Gerar Link de Senha** para o cliente
2. Envie o link por e-mail ou WhatsApp
3. Quando o cliente ativar a conta, gere o cronograma automático de preventivas

---

### Gerando o Cronograma Automático de Preventivas

1. Acesse `/admin/manutencao/clientes/:id` (detalhe do cliente)
2. Clique na aba **Preventivas**
3. Clique em **Cronograma Automático**
4. Selecione a data da primeira visita
5. Revise as datas geradas automaticamente (editáveis antes de confirmar)
6. Clique em **Confirmar e Gerar**

O sistema criará todas as visitas do plano:
- Plano trimestral: 3 visitas
- Plano semestral: 6 visitas
- Plano anual: 12 visitas

---

### Enviando um Orçamento para o Cliente

1. Acesse a aba **Orçamentos** no painel admin
2. Clique em **+ Novo Orçamento**
3. Selecione o cliente
4. Preencha título, descrição e valor
5. Faça upload do PDF do orçamento
6. Clique em **Enviar**
7. O cliente receberá o orçamento no portal e poderá responder

**Se o cliente sugerir um ajuste:**
1. Você verá a sugestão do cliente na lista de orçamentos
2. Clique em **Responder**
3. Faça upload do novo PDF revisado
4. Clique em **Reenviar**
5. O cliente receberá o novo orçamento para avaliação

---

### Cadastrando um Novo Técnico

1. Acesse a aba **Técnicos**
2. Clique em **+ Novo Técnico**
3. Preencha nome, e-mail, telefone, CPF e especialidades
4. Clique em **Salvar**
5. O técnico receberá acesso com a senha padrão `tecnico1234`
6. Vincule o técnico às lojas que ele atenderá clicando em **Vincular a Cliente**

---

### Gerenciando Chamados de Suporte

1. Acesse a aba **Suporte**
2. Você verá todos os chamados abertos pelos técnicos
3. Clique em **Responder** para adicionar notas e alterar o status
4. Status disponíveis: Aberto, Em Andamento, Resolvido, Fechado
