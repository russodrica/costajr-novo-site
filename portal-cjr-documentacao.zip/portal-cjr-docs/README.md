# Portal CJR — Documentação Completa

**Sistema:** Portal CJR — Plataforma de Gestão de Manutenção Preventiva  
**Empresa:** Costa Júnior (CJR)  
**Domínio:** [portalcjr.vip](https://portalcjr.vip)  
**Data:** Junho de 2026

---

## Índice de Documentos

| # | Documento | Descrição |
|---|---|---|
| 01 | [Visão Geral do Sistema](01_visao_geral.md) | Objetivo, público-alvo, funcionalidades e fluxos principais |
| 02 | [Arquitetura Completa](02_arquitetura.md) | Stack tecnológica, estrutura de pastas, autenticação e S3 |
| 03 | [Modelagem de Dados](03_modelagem_dados.md) | Todas as tabelas com campos, tipos e relacionamentos |
| 04 | [Documentação das Telas](04_documentacao_telas.md) | Mapa de rotas, campos, botões e navegação de cada tela |
| 05 | [Documentação das APIs](05_documentacao_apis.md) | Todas as procedures tRPC com inputs, outputs e exemplos |
| 06 | [Regras de Negócio](06_regras_negocio.md) | Precificação, cronograma, fluxos de aprovação e cálculos |
| 07 | [Usuários e Permissões](07_usuarios_permissoes.md) | Perfis, permissões por módulo e verificação de acesso |
| 08 | [Manual de Implantação](08_manual_implantacao.md) | Instalação, configuração, variáveis de ambiente e deploy |
| 09 | [Manual do Usuário](09_manual_usuario.md) | Guias passo a passo para cliente, técnico e administrador |
| 10 | [Código Fonte Organizado](10_codigo_fonte.md) | Estrutura de pastas, padrões de código e arquivos críticos |
| 11 | [Roadmap Futuro](11_roadmap_futuro.md) | Bugs conhecidos, melhorias planejadas e débitos técnicos |

---

## Diagramas

| Diagrama | Formato | Descrição |
|---|---|---|
| [Arquitetura do Sistema](diagrams/arquitetura.png) | PNG | Visão geral da arquitetura (browser → servidor → banco → serviços) |
| [Banco de Dados (ER)](diagrams/banco_dados.png) | PNG | Diagrama entidade-relacionamento do módulo de manutenção |
| [Fluxo de Visita Preventiva](diagrams/fluxo_preventiva.png) | PNG | Fluxo completo de execução de uma visita preventiva |
| [Fluxo de Negociação de Orçamento](diagrams/fluxo_orcamento.png) | PNG | Estados e transições do fluxo de orçamentos |
| [Fluxo de Autenticação](diagrams/autenticacao.png) | PNG | Sequência de autenticação OAuth e e-mail+senha |

---

## Exportações

| Arquivo | Formato | Conteúdo |
|---|---|---|
| `Portal_CJR_Documentacao_Completa.pdf` | PDF | Todos os 11 documentos em um único PDF |
| `Portal_CJR_Documentacao_Completa.docx` | Word | Todos os 11 documentos em formato editável |

---

## Resumo do Sistema

O Portal CJR é uma plataforma web completa para gestão de manutenção preventiva, construída com:

- **Frontend:** React 19 + TypeScript + Tailwind CSS 4 + shadcn/ui
- **Backend:** Node.js + Express 4 + tRPC 11 + Drizzle ORM
- **Banco:** TiDB (compatível MySQL)
- **Arquivos:** AWS S3
- **Autenticação:** Manus OAuth (internos) + E-mail/Senha (clientes e técnicos)
- **Pagamentos:** Mercado Pago

O sistema atende três perfis: **Administrador CJR** (gestão completa), **Técnico de Manutenção** (execução de visitas com checklist e PDF) e **Cliente/Lojista** (acompanhamento, aprovações e orçamentos).
