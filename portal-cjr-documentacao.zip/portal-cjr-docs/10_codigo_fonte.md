# Portal CJR — Documentação Completa
## Documento 10: Código Fonte Organizado

---

## 10.1 Estrutura de Pastas Detalhada

```
forum-cjr/
│
├── client/                              # Frontend React (SPA)
│   ├── index.html                       # Entry point HTML com Google Fonts
│   ├── public/                          # Assets estáticos (copiados para /)
│   │   └── logo.png                     # Logo CJR
│   └── src/
│       ├── App.tsx                      # ⭐ Roteamento principal (Wouter)
│       │                                #    Todos os <Route> do sistema
│       ├── main.tsx                     # Providers: ThemeProvider, tRPC, QueryClient
│       ├── index.css                    # Variáveis CSS globais (Tailwind 4 tokens)
│       ├── const.ts                     # getLoginUrl(), constantes globais
│       │
│       ├── components/
│       │   ├── ui/                      # Componentes shadcn/ui (NÃO editar)
│       │   │   ├── button.tsx
│       │   │   ├── dialog.tsx
│       │   │   ├── tabs.tsx
│       │   │   └── ... (30+ componentes)
│       │   ├── DashboardLayout.tsx      # Layout sidebar para painéis internos
│       │   ├── ManutencaoLayout.tsx     # ⭐ Sidebar do módulo de manutenção
│       │   ├── ComercialLayout.tsx      # Sidebar do módulo comercial
│       │   ├── AIChatBox.tsx            # Componente de chat com IA
│       │   ├── ErrorBoundary.tsx        # Tratamento de erros React
│       │   └── Map.tsx                  # Integração Google Maps
│       │
│       ├── contexts/
│       │   └── ThemeContext.tsx         # Contexto de tema (light/dark)
│       │
│       ├── hooks/
│       │   ├── useMobile.tsx            # Detecção de dispositivo móvel
│       │   └── usePersistFn.ts          # Hook para funções persistentes
│       │
│       ├── lib/
│       │   ├── trpc.ts                  # ⭐ Configuração do cliente tRPC
│       │   ├── utils.ts                 # cn() e outros utilitários
│       │   └── cjrLogoB64.ts            # ⭐ Logo CJR em base64 (para PDF)
│       │
│       └── pages/
│           ├── Home.tsx                 # Landing page / hub de navegação
│           ├── Chat.tsx                 # Fórum de dúvidas com IA
│           ├── Dashboard.tsx            # Dashboard do usuário interno
│           ├── Treinamentos.tsx         # Biblioteca de treinamentos
│           ├── GestaoTecnica.tsx        # Gestão técnica (estoque, equipamentos)
│           ├── DocumentosTecnicos.tsx   # Documentos técnicos
│           ├── TermoEntrega.tsx         # Geração de Termo de Entrega
│           ├── AtaReuniao.tsx           # Geração de Ata de Reunião
│           ├── Perfil.tsx               # Perfil do usuário
│           ├── MinhasSubmissoes.tsx     # Submissões de conhecimento
│           ├── Onboarding.tsx           # Onboarding de novos colaboradores
│           │
│           ├── TecnicoPortal.tsx        # ⭐ Portal do técnico (/tecnico)
│           ├── ClientePortal.tsx        # ⭐ Portal do cliente (/cliente)
│           ├── ClienteLogin.tsx         # Login do cliente
│           ├── TecnicoLogin.tsx         # Login do técnico
│           ├── ClienteDefinirSenha.tsx  # Definir senha (token)
│           ├── TecnicoDefinirSenha.tsx  # Definir senha (token)
│           ├── ClienteTrocarSenha.tsx   # Trocar senha (autenticado)
│           ├── TecnicoTrocarSenha.tsx   # Trocar senha (autenticado)
│           │
│           ├── admin/
│           │   ├── AdminManutencao.tsx      # ⭐ Painel admin de manutenção
│           │   ├── AdminClienteDetalhe.tsx  # ⭐ Detalhe do cliente (admin)
│           │   ├── AdminDashboard.tsx       # Dashboard admin geral
│           │   ├── Users.tsx                # Gestão de usuários
│           │   ├── Documents.tsx            # Gestão de documentos
│           │   ├── Questions.tsx            # Gestão de perguntas
│           │   ├── Knowledge.tsx            # Base de conhecimento
│           │   ├── TechnicalDocuments.tsx   # Documentos técnicos (admin)
│           │   ├── AdminConteudo.tsx        # Gestão de conteúdo
│           │   ├── AdminTrainingReport.tsx  # Relatório de treinamentos
│           │   ├── MapaPaginas.tsx          # Mapa de páginas
│           │   └── AdminSubmissoesConhecimento.tsx
│           │
│           ├── manutencao/
│           │   ├── DashboardManutencao.tsx  # Dashboard gestão
│           │   ├── ClientesManutencao.tsx   # Listagem de clientes
│           │   ├── ClienteDetalhe.tsx       # Detalhe do cliente (gestão)
│           │   ├── ChamadosManutencao.tsx   # Gestão de chamados
│           │   ├── AgendaManutencao.tsx     # Agenda de visitas
│           │   ├── TecnicosManutencao.tsx   # Gestão de técnicos
│           │   ├── PreventivosManutencao.tsx # Gestão de preventivos
│           │   ├── OrcamentosManutencao.tsx # ⭐ Gestão de orçamentos
│           │   └── ContratarManutencao.tsx  # Contratação pública
│           │
│           └── comercial/
│               ├── DashboardComercial.tsx   # Dashboard comercial
│               ├── Prospeccao.tsx           # CRM de prospecção
│               ├── PadroesComerciais.tsx    # Padrões comerciais
│               └── FerramentasComerciais.tsx # Ferramentas comerciais
│
├── server/                              # Backend Node.js/Express
│   ├── _core/                           # Framework (NÃO editar)
│   │   ├── index.ts                     # Entry point: Express + tRPC + OAuth
│   │   ├── trpc.ts                      # publicProcedure, protectedProcedure
│   │   ├── context.ts                   # Contexto: { user, req, res }
│   │   ├── oauth.ts                     # Manus OAuth handler
│   │   ├── cookies.ts                   # Configuração de cookies (SameSite, etc.)
│   │   ├── llm.ts                       # invokeLLM() helper
│   │   ├── notification.ts              # notifyOwner() helper
│   │   ├── env.ts                       # Variáveis de ambiente tipadas
│   │   ├── imageGeneration.ts           # generateImage() helper
│   │   └── voiceTranscription.ts        # transcribeAudio() helper
│   │
│   ├── routers/
│   │   ├── manutencao.ts                # ⭐ Router admin de manutenção
│   │   ├── clientAuth.ts                # ⭐ Router cliente/técnico + portais
│   │   ├── _clientDetail.ts             # Helper: adminGetClientDetail
│   │   ├── auth.ts                      # Router OAuth (me, logout)
│   │   ├── documents.ts                 # Router de documentos
│   │   ├── knowledge.ts                 # Router da base de conhecimento
│   │   ├── chat.ts                      # Router do chat com IA
│   │   ├── users.ts                     # Router de usuários
│   │   ├── training.ts                  # Router de treinamentos
│   │   ├── inventory.ts                 # Router de estoque
│   │   ├── prospect.ts                  # Router de prospecção comercial
│   │   └── ...
│   │
│   ├── db.ts                            # ⭐ Helpers de query (getDb, etc.)
│   ├── storage.ts                       # ⭐ storagePut(), storageGet()
│   └── routers.ts                       # Agregador de todos os routers
│
├── drizzle/
│   ├── schema.ts                        # ⭐ Definição de TODAS as tabelas
│   └── migrations/                      # Arquivos SQL de migração
│
├── shared/
│   └── types.ts                         # Tipos compartilhados
│
├── package.json                         # Dependências e scripts
├── tsconfig.json                        # TypeScript (strict mode)
├── vite.config.ts                       # Vite: React plugin + proxy /api
├── drizzle.config.ts                    # Drizzle: schema path + dialect
└── todo.md                              # Lista de tarefas do projeto
```

---

## 10.2 Padrões de Código

### Convenções de Nomenclatura

| Tipo | Padrão | Exemplo |
|---|---|---|
| Componentes React | PascalCase | `ClientePortal.tsx` |
| Funções/variáveis | camelCase | `generateToken()` |
| Constantes | UPPER_SNAKE_CASE | `SESSION_COOKIE_CLIENT` |
| Tabelas do banco | camelCase | `maintenanceClients` |
| Campos do banco | camelCase | `contractStatus` |
| Procedures tRPC | camelCase | `clientLogin`, `techExecuteVisit` |
| Rotas URL | kebab-case | `/login-cliente`, `/admin/manutencao` |

### Padrão de Procedure tRPC

```typescript
// ✅ Padrão correto para procedure protegida
procedureName: protectedProcedure
  .input(z.object({
    id: z.number(),
    name: z.string().min(1).max(255),
    optional: z.string().optional(),
  }))
  .mutation(async ({ input, ctx }) => {
    // Verificação de permissão
    if (ctx.user.role !== "admin") {
      throw new TRPCError({ code: "FORBIDDEN" });
    }
    
    const db = await getDb();
    if (!db) throw new Error("Banco de dados indisponível.");
    
    // Lógica de negócio
    await db.insert(table).values({ ...input });
    
    return { ok: true };
  }),
```

### Padrão de Verificação de Sessão de Cliente

```typescript
// ✅ Padrão para procedures do portal do cliente
clientProcedure: publicProcedure
  .input(z.object({ storeId: z.number() }))
  .query(async ({ input, ctx }) => {
    const req = (ctx as any).req as Request;
    const token = req.cookies?.[SESSION_COOKIE_CLIENT];
    if (!token) throw new TRPCError({ code: "UNAUTHORIZED" });
    
    const db = await getDb();
    if (!db) throw new Error("Banco de dados indisponível.");
    
    const now = new Date();
    const sessions = await db.select().from(clientSessions)
      .where(and(
        eq(clientSessions.token, token),
        gt(clientSessions.expiresAt, now)
      ))
      .limit(1);
    
    if (!sessions[0]) throw new TRPCError({ code: "UNAUTHORIZED" });
    
    const clientId = sessions[0].clientId;
    // ... lógica de negócio
  }),
```

### Padrão de Upload para S3

```typescript
// ✅ Padrão para upload de arquivo
if (input.fileBase64 && input.fileMime) {
  const buffer = Buffer.from(input.fileBase64, "base64");
  const ext = input.fileMime.includes("pdf") ? "pdf" : "png";
  const randomSuffix = Math.random().toString(36).substring(2, 10);
  const fileKey = `quotes/${quoteId}/quote-${randomSuffix}.${ext}`;
  const { url } = await storagePut(fileKey, buffer, input.fileMime);
  fileUrl = url;
}
```

### Padrão de Query no Frontend

```typescript
// ✅ Query com estado de loading e erro
const { data: clients, isLoading, error } = trpc.manutencao.listClients.useQuery(
  { search: searchTerm },
  { enabled: !!searchTerm }  // Só executa se searchTerm não for vazio
);

if (isLoading) return <Spinner />;
if (error) return <ErrorMessage message={error.message} />;
if (!clients?.length) return <EmptyState />;
```

### Padrão de Mutation no Frontend

```typescript
// ✅ Mutation com invalidação de cache
const utils = trpc.useUtils();

const createVisit = trpc.manutencao.createVisit.useMutation({
  onSuccess: () => {
    // Invalida as queries relacionadas para refetch automático
    utils.manutencao.listClients.invalidate();
    setModalOpen(false);
    toast.success("Visita agendada com sucesso!");
  },
  onError: (err) => {
    toast.error(err.message);
  },
});

// Chamada da mutation
createVisit.mutate({
  clientId: selectedClient.id,
  scheduledDate: "2026-07-15",
  scheduledTime: "09:00",
});
```

---

## 10.3 Arquivos Críticos e Suas Funções

### `drizzle/schema.ts`
Define todas as tabelas do banco de dados. **Toda alteração no banco começa aqui.** Após editar, execute `pnpm db:push`.

### `server/routers/manutencao.ts`
Router principal do módulo de manutenção. Contém todas as procedures acessíveis por usuários internos (admin, coordenador, etc.). Inclui a lógica de precificação e geração de cronograma.

### `server/routers/clientAuth.ts`
Router de autenticação e portais de clientes e técnicos. Contém o sistema de sessão independente (cookie-based) e todas as procedures dos portais `/cliente` e `/tecnico`.

### `server/routers/_clientDetail.ts`
Helper que consolida todos os dados de um cliente em uma única query. Usado pela tela de detalhe do cliente no admin.

### `client/src/pages/TecnicoPortal.tsx`
Portal completo do técnico. Contém o checklist de 36 itens, a lógica de captura de fotos, assinatura digital e geração do PDF com jspdf.

### `client/src/pages/ClientePortal.tsx`
Portal completo do cliente. Contém os fluxos de aprovação de materiais, negociação de orçamentos e upload de comprovantes.

### `client/src/pages/admin/AdminManutencao.tsx`
Painel administrativo principal. Contém todas as abas de gestão (clientes, técnicos, leads, preços, cupons, contrato, orçamentos, suporte).

### `client/src/pages/admin/AdminClienteDetalhe.tsx`
Página de detalhe do cliente com 6 abas. Contém o modal de cronograma automático com preview das datas.

### `client/src/lib/cjrLogoB64.ts`
Logo CJR em formato base64 para embutir no PDF de preventiva. Se o logo mudar, este arquivo deve ser atualizado.

---

## 10.4 Notas sobre TypeScript

O projeto usa TypeScript em modo strict. Há aproximadamente 48 erros de tipo no arquivo `server/routers/manutencao.ts` relacionados a importações de tipos do Drizzle ORM que **não afetam o funcionamento** em runtime. Estes erros existem desde o início do projeto e podem ser ignorados nas verificações de CI.

Para verificar erros TypeScript reais:
```bash
pnpm tsc --noEmit 2>&1 | grep -v "manutencao.ts"
```

---

## 10.5 Testes

O projeto usa Vitest para testes unitários. O arquivo de referência é `server/auth.logout.test.ts`.

Para executar os testes:
```bash
pnpm test
```

Para executar com cobertura:
```bash
pnpm test --coverage
```

**Áreas que precisam de cobertura de testes:**
- Lógica de precificação (`calculatePrice`)
- Geração de cronograma automático
- Verificação de sessão de cliente/técnico
- Fluxo de negociação de orçamentos
