# Portal CJR — Documentação Completa
## Documento 01: Visão Geral do Sistema

**Empresa:** Costa Júnior (CJR)  
**Sistema:** Portal CJR — Plataforma de Gestão de Manutenção Preventiva  
**Domínio:** [portalcjr.vip](https://portalcjr.vip)  
**Versão documentada:** Checkpoint `8317a97c`  
**Data de referência:** Junho de 2026

---

## 1.1 Objetivo do Aplicativo

O Portal CJR é uma plataforma web completa de gestão de manutenção preventiva desenvolvida para a empresa Costa Júnior (CJR). O sistema centraliza todo o ciclo de vida dos contratos de manutenção: desde a captação de novos clientes (lojistas de shopping centers) até a execução das visitas técnicas preventivas, geração de relatórios em PDF com assinatura digital, controle financeiro e negociação de orçamentos de serviços extras.

O sistema resolve a necessidade de digitalizar e automatizar um processo que anteriormente era conduzido de forma manual — agendamentos em planilhas, relatórios em papel e comunicações por WhatsApp —, oferecendo rastreabilidade completa, histórico de visitas, evidências fotográficas e fluxos de aprovação estruturados.

---

## 1.2 Público-Alvo

O sistema atende três perfis distintos de usuário, cada qual com seu próprio portal de acesso:

| Perfil | Portal de Acesso | Descrição |
|---|---|---|
| **Técnico de Manutenção** | `/tecnico` | Profissional de campo que executa as visitas preventivas e corretivas nas lojas dos clientes. |
| **Cliente (Lojista)** | `/cliente` | Responsável pela loja contratante do plano de manutenção preventiva. Acompanha visitas, aprova materiais e orçamentos. |
| **Administrador CJR** | `/admin/manutencao` e `/manutencao/*` | Equipe interna da CJR que gerencia clientes, técnicos, agendamentos, orçamentos e financeiro. |

Além desses três perfis principais do módulo de manutenção, a plataforma também serve colaboradores internos da CJR (perfis: `admin`, `coordenador`, `administrativo`, `financeiro`, `operacional`, `comercial`) que utilizam outros módulos do sistema (Fórum de Dúvidas, Treinamentos, Gestão Comercial, etc.).

---

## 1.3 Principais Funcionalidades

### Módulo de Manutenção Preventiva (foco desta documentação)

**Para o Administrador CJR:**
- Cadastro e gestão completa de clientes (lojistas) com código único (ex.: `CLT-0001`)
- Gestão de técnicos de manutenção com vinculação a clientes específicos
- Simulador de preços com cálculo automático por tipo de loja, serviços e plano
- Fluxo de pré-cadastro (leads) com Kanban de prospecção e integração Mercado Pago
- Geração automática de cronograma de preventivas (1 visita/mês conforme plano)
- Painel de detalhe do cliente com 6 abas: Lojas, Preventivas, Relatórios, Materiais, Financeiro e Orçamentos
- Upload e envio de orçamentos em PDF para clientes
- Aprovação de solicitações de material com taxa administrativa (~30%)
- Gestão de chamados de suporte abertos por técnicos
- Configuração de texto do contrato de adesão
- Exportação de dados em CSV

**Para o Técnico:**
- Visualização de lojas vinculadas e agenda de visitas
- Checklist de preventiva com 36 itens (Civil, Hidráulica, Elétrica) com foto obrigatória por item
- Abertura e execução de chamados corretivos com foto do problema
- Solicitação de materiais durante a visita
- Assinatura digital do cliente ao final da visita
- Geração automática de PDF do relatório com logo CJR, dados da visita, fotos e assinatura
- Aba de suporte técnico para abertura de chamados internos

**Para o Cliente:**
- Dashboard com gráfico de chamados por tipo (anual)
- Visualização de todas as lojas do mesmo grupo (mesmo `clientCode`)
- Acompanhamento de chamados com foto e localização do problema
- Histórico de visitas preventivas com acesso ao PDF do relatório
- Aprovação ou rejeição de solicitações de material com upload de comprovante de pagamento
- Fluxo de negociação de orçamentos: aprovação, rejeição ou sugestão de ajuste (ciclo iterativo)
- Acesso ao contrato de adesão
- Edição de perfil (e-mail e telefone)

### Outros Módulos da Plataforma

- **Fórum de Dúvidas:** Chat com IA (LLM) alimentado por base de conhecimento, com escalação para resposta humana
- **Treinamentos:** Biblioteca de vídeos e PDFs organizados por área (Administrativo, Financeiro, Operacional, Comercial)
- **Gestão Comercial:** CRM de prospecção com Kanban, histórico de interações, tarefas e templates de e-mail
- **Documentos:** Geração de Termos de Entrega e Atas de Reunião com assinatura digital
- **Gestão Técnica:** Controle de estoque (inventário) e equipamentos

---

## 1.4 Fluxo Geral de Utilização

### Fluxo de Contratação (Novo Cliente)

```
1. Lojista acessa /manutencao/contratar
2. Preenche dados da loja e simula o preço
3. Escolhe o plano (trimestral/semestral/anual)
4. Assina o contrato digitalmente
5. Realiza o pagamento via Mercado Pago
6. Lead é registrado no sistema (status: "novo")
7. Admin CJR converte o lead em cliente ativo
8. Admin gera link de criação de senha para o cliente
9. Admin gera cronograma automático de preventivas
10. Cliente recebe acesso ao portal /cliente
```

### Fluxo de Visita Preventiva

```
1. Admin agenda visita para um técnico
2. Técnico acessa /tecnico e vê a agenda
3. Técnico executa o checklist de 36 itens com fotos
4. Técnico coleta assinatura digital do responsável da loja
5. Sistema gera PDF do relatório automaticamente
6. PDF fica disponível para o cliente em /cliente (aba Preventivas)
7. Admin visualiza o relatório na aba Relatórios do detalhe do cliente
```

### Fluxo de Solicitação de Material

```
1. Técnico solicita material durante a visita (descrição + valor estimado)
2. Cliente recebe notificação e aprova ou rejeita em /cliente
3. Se aprovado, cliente realiza o pagamento
4. Cliente faz upload do comprovante de pagamento
5. Admin visualiza o comprovante na aba Materiais
```

### Fluxo de Orçamento de Serviço Extra

```
1. Admin cria orçamento e faz upload do PDF
2. Cliente recebe o orçamento em /cliente (aba Orçamentos)
3. Cliente pode: Aprovar | Rejeitar | Sugerir Ajuste
4. Se "Sugerir Ajuste": cliente descreve a sugestão
5. Admin vê a sugestão e pode reenviar novo PDF (nova rodada)
6. Ciclo se repete até aprovação ou rejeição definitiva
```
