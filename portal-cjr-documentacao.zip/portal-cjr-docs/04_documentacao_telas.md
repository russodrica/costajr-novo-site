# Portal CJR — Documentação Completa
## Documento 04: Documentação das Telas

---

## 4.1 Mapa de Rotas

| Rota | Componente | Acesso | Descrição |
|---|---|---|---|
| `/` | `Home` | Público | Hub de navegação / landing page |
| `/login-cliente` | `ClienteLogin` | Público | Login do cliente |
| `/login-tecnico` | `TecnicoLogin` | Público | Login do técnico |
| `/cliente/definir-senha` | `ClienteDefinirSenha` | Token URL | Definir senha inicial (cliente) |
| `/tecnico/definir-senha` | `TecnicoDefinirSenha` | Token URL | Definir senha inicial (técnico) |
| `/cliente/trocar-senha` | `ClienteTrocarSenha` | Autenticado | Trocar senha (cliente) |
| `/tecnico/trocar-senha` | `TecnicoTrocarSenha` | Autenticado | Trocar senha (técnico) |
| `/cliente` | `ClientePortal` | Cliente autenticado | Portal completo do cliente |
| `/tecnico` | `TecnicoPortal` | Técnico autenticado | Portal completo do técnico |
| `/manutencao/contratar` | `ContratarManutencao` | Público | Fluxo de contratação online |
| `/manutencao/dashboard` | `DashboardManutencao` | Usuário interno | Dashboard de manutenção |
| `/manutencao/clientes` | `ClientesManutencao` | Usuário interno | Listagem de clientes |
| `/manutencao/clientes/:id` | `ClienteDetalhe` | Usuário interno | Detalhe do cliente |
| `/manutencao/chamados` | `ChamadosManutencao` | Usuário interno | Gestão de chamados |
| `/manutencao/agenda` | `AgendaManutencao` | Usuário interno | Agenda de visitas |
| `/manutencao/tecnicos` | `TecnicosManutencao` | Admin | Gestão de técnicos |
| `/manutencao/preventivos` | `PreventivosManutencao` | Admin | Gestão de preventivos |
| `/manutencao/orcamentos` | `OrcamentosManutencao` | Admin | Gestão de orçamentos |
| `/admin/manutencao` | `AdminManutencao` | Admin | Painel administrativo completo |
| `/admin/manutencao/clientes/:id` | `AdminClienteDetalhe` | Admin | Detalhe do cliente (admin) |

---

## 4.2 Telas do Portal do Cliente (`/cliente`)

### Tela: Login do Cliente (`/login-cliente`)

**Objetivo:** Autenticar o cliente (lojista) no portal.

**Campos:**
- E-mail (obrigatório)
- Senha (obrigatório, mínimo 6 caracteres)

**Botões e Ações:**
- `Entrar` — chama `clientAuth.clientLogin`; em caso de sucesso, redireciona para `/cliente`
- `Esqueci minha senha` — redireciona para fluxo de reset (não implementado na UI, mas disponível via admin)

**Validações:**
- E-mail e senha são obrigatórios
- Se `mustChangePassword = true`, redireciona para `/cliente/trocar-senha` após login

**Navegação:** Após login bem-sucedido → `/cliente`

---

### Tela: Portal do Cliente (`/cliente`)

**Objetivo:** Central de acesso do cliente para acompanhar todos os serviços de manutenção.

**Seções principais (menu lateral/tabs):**
- `dashboard` — Visão geral com gráfico de chamados
- `lojas` — Listagem e detalhes das lojas
- `plano` — Informações do plano contratado
- `termo` — Contrato de adesão

**Seção Dashboard:**
- Gráfico de pizza (recharts) com chamados por categoria no ano atual
- Cards com contadores: total de chamados, chamados abertos, preventivas realizadas

**Seção Lojas (por loja selecionada):**
Tabs internas:
- `chamados` — Lista de chamados com status, categoria, prioridade, foto e localização
  - Botão `+ Novo Chamado` → modal com campos: título, descrição, categoria, prioridade, localização, foto
  - Botão `Aprovar` / `Rejeitar` em chamados pendentes de material
- `preventivas` — Histórico de visitas preventivas com status e link para PDF do relatório
  - Card com próxima preventiva (badge colorido por urgência)
- `checklist` — Visualização do checklist da última preventiva
- `orcamentos` — Lista de orçamentos com status e fluxo de negociação
  - Botão `Aprovar` → chama `clientAuth.clientRespondQuote` com `action: "aprovado"`
  - Botão `Rejeitar` → modal com campo de feedback → `action: "rejeitado"`
  - Botão `Sugerir Ajuste` → modal com campo de sugestão → `action: "ajuste"`, preenche `clientSuggestion`
  - Botão `Ver PDF` → abre URL do PDF em nova aba
- `materiais` — Lista de solicitações de material
  - Botão `Aprovar` / `Rejeitar` em solicitações pendentes
  - Botão `Enviar Comprovante` (após aprovação) → modal com upload de imagem/PDF → `clientAuth.clientUploadMaterialReceipt`
  - Botão `Ver Comprovante` (após upload) → abre URL

**Seção Plano:**
- Exibe tipo de plano, valor mensal, serviços incluídos, datas de início/fim

**Seção Termo:**
- Exibe o texto do contrato de adesão (carregado de `systemSettings` com chave `"contract_text"`)

**Redirecionamentos:**
- Se não autenticado → `/login-cliente`
- Se `mustChangePassword = true` → `/cliente/trocar-senha`

---

## 4.3 Telas do Portal do Técnico (`/tecnico`)

### Tela: Login do Técnico (`/login-tecnico`)

**Objetivo:** Autenticar o técnico no portal.

**Campos:**
- E-mail (obrigatório)
- Senha (obrigatório)

**Botões:** `Entrar` — chama `clientAuth.techLogin`

**Navegação:** Após login → `/tecnico`

---

### Tela: Portal do Técnico (`/tecnico`)

**Objetivo:** Interface de trabalho do técnico de campo.

**Tabs principais:**
- `lojas` — Lojas vinculadas ao técnico
- `agenda` — Agenda de visitas agendadas
- `chamados` — Chamados atribuídos ao técnico

**Tab Lojas:**
- Lista de lojas vinculadas via `technicianClientLinks`
- Por loja, sub-tabs: `chamados`, `preventivas`, `checklist`, `materiais`

**Tab Agenda:**
- Calendário/lista de visitas agendadas
- Badge colorido com próxima preventiva
- Clique no badge → modal com lista de lojas com preventiva no mesmo dia

**Tab Chamados:**
- Lista de chamados atribuídos
- Botão `Executar` → abre painel de execução:
  - Atualização de status
  - Foto obrigatória ao concluir
  - Visualização da foto/localização do problema
  - Botão `Solicitar Material` → modal com campos: descrição, valor estimado

**Execução de Visita Preventiva (Checklist):**

Ao iniciar uma visita preventiva, o técnico acessa o checklist de 36 itens divididos em 3 grupos:

**CIVIL (12 itens):**
1. Verificação de pisos e revestimentos
2. Inspeção de paredes e forros
3. Verificação de portas e janelas
4. Inspeção de calhas e rufos
5. Verificação de impermeabilização
6. Inspeção de estrutura metálica
7. Verificação de pintura
8. Inspeção de vidros e esquadrias
9. Verificação de fechaduras e ferragens
10. Inspeção de sinalização
11. Verificação de acessibilidade
12. Inspeção geral de acabamentos

**HIDRÁULICA (12 itens):**
1. Verificação de torneiras e registros
2. Inspeção de vasos sanitários
3. Verificação de pias e cubas
4. Inspeção de ralos e sifões
5. Verificação de caixas d'água
6. Inspeção de bombas d'água
7. Verificação de aquecedores
8. Inspeção de tubulações aparentes
9. Verificação de pressão da água
10. Inspeção de válvulas de descarga
11. Verificação de chuveiros
12. Inspeção de sistema de esgoto

**ELÉTRICA (12 itens):**
1. Verificação de quadro elétrico
2. Inspeção de disjuntores
3. Verificação de tomadas e interruptores
4. Inspeção de iluminação
5. Verificação de aterramento
6. Inspeção de fiação aparente
7. Verificação de ar-condicionado
8. Inspeção de nobreaks e estabilizadores
9. Verificação de câmeras de segurança
10. Inspeção de alarmes
11. Verificação de SPDA (para-raios)
12. Inspeção geral de equipamentos elétricos

**Para cada item:**
- Checkbox de conclusão
- Botão de câmera → captura foto (obrigatória para itens marcados como concluídos)
- A foto é armazenada em base64 no estado local e incluída no PDF

**Finalização da Visita:**
1. Técnico preenche observações gerais
2. Tela de assinatura digital (canvas com `signature_pad`)
3. Campo para nome do assinante
4. Botão `Gerar Relatório e Finalizar`:
   - Gera PDF com jspdf (logo CJR, dados, checklist, fotos, assinatura)
   - Envia PDF como base64 para o servidor via `clientAuth.techExecuteVisit`
   - Servidor salva PDF no S3 e atualiza `maintenanceVisits.reportPdfUrl`

**Tab Suporte:**
- Lista de chamados de suporte abertos pelo técnico
- Botão `+ Novo Chamado de Suporte` → modal com campos: descrição, foto opcional
- Chama `clientAuth.techCreateSupportTicket`

---

## 4.4 Telas do Painel Administrativo

### Tela: Painel Admin de Manutenção (`/admin/manutencao`)

**Objetivo:** Central de gestão completa do módulo de manutenção para a equipe CJR.

**Tabs:**
- `dashboard` — Métricas gerais (total de clientes, visitas, chamados, receita)
- `clientes` — Listagem e gestão de clientes
- `leads` — Pré-cadastros e prospecção
- `tecnicos` — Gestão de técnicos
- `equipe` — Controle de acesso da equipe interna
- `precos` — Configuração de tabela de preços
- `cupons` — Gestão de cupons de desconto
- `contrato` — Edição do texto do contrato de adesão
- `orcamentos` — Listagem de todos os orçamentos
- `suporte` — Chamados de suporte dos técnicos

**Tab Clientes:**
- Cards compactos com código, nome da empresa, loja, status do contrato
- Botão `Ver Detalhes` → navega para `/admin/manutencao/clientes/:id`
- Botão `+ Novo Cliente` → modal com formulário completo de cadastro
- Filtros por status do contrato
- Exportação CSV

**Tab Orçamentos:**
- Cards de orçamentos com status, cliente, valor, rodada de negociação
- Filtros por status
- Botão `Responder` → modal com campos: texto de resposta, valor, prazo, upload de PDF
- Botão `+ Novo Orçamento` → modal com campos: cliente, título, descrição, valor, upload de PDF
- Chama `clientAuth.adminRespondQuote` (resposta) ou `manutencao.adminUploadQuote` (novo)

**Tab Suporte:**
- Lista de chamados de suporte com status
- Botão `Responder/Fechar` → modal com campo de notas e mudança de status

---

### Tela: Detalhe do Cliente — Admin (`/admin/manutencao/clientes/:id`)

**Objetivo:** Visão consolidada de todos os dados de um cliente específico.

**6 Abas:**

**Aba Lojas:**
- Lista todas as lojas do cliente (mesmo `clientCode`)
- Status de aprovação de cada loja
- Botão `Aprovar` / `Rejeitar` para lojas pendentes

**Aba Preventivas:**
- Lista de visitas preventivas agendadas e concluídas
- Botão `+ Agendar Visita` → modal com campos: data, hora, técnico
- Botão `Cronograma Automático` → modal com:
  - Data de início (editável)
  - Preview das datas geradas (1ª visita = data informada, 2ª = +10 dias, demais = +30 dias)
  - Botão `Confirmar e Gerar` → chama `manutencao.generatePreventiveSchedule`

**Aba Relatórios:**
- Lista de visitas concluídas com PDF disponível
- Botão `Ver Relatório` → abre PDF em nova aba

**Aba Materiais:**
- Lista de solicitações de material com status
- Botão `Aprovar` / `Reprovar` → chama `manutencao.approveMaterial`

**Aba Financeiro:**
- Resumo financeiro: total de manutenção, total de materiais, total geral
- Calculado pela procedure `adminGetClientDetail`

**Aba Orçamentos:**
- Lista de orçamentos do cliente
- Botão `Responder` → modal de resposta com upload de PDF

---

### Tela: Contratação Online (`/manutencao/contratar`)

**Objetivo:** Fluxo público de contratação de plano de manutenção.

**Etapas:**
1. **Dados da Loja:** nome, shopping, tipo de loja, serviços desejados
2. **Simulação:** exibe preço calculado por plano (trimestral/semestral/anual) com desconto
3. **Dados Completos:** CNPJ, razão social, endereço, responsável, WhatsApp
4. **Contrato:** exibe texto do contrato, campo de assinatura (nome), checkbox de aceite
5. **Pagamento:** integração Mercado Pago (link de pagamento gerado)

**Validações:**
- Todos os campos obrigatórios devem ser preenchidos antes de avançar
- Cupom de desconto pode ser aplicado na etapa de simulação
- Contrato deve ser aceito antes de prosseguir para pagamento

---

## 4.5 Telas do Módulo de Gestão (Usuários Internos)

### Tela: Dashboard de Manutenção (`/manutencao/dashboard`)

**Objetivo:** Visão geral operacional do módulo de manutenção.

**Conteúdo:**
- Cards com KPIs: total de clientes ativos, visitas do mês, chamados abertos, receita mensal
- Gráficos de tendência

---

### Tela: Listagem de Clientes (`/manutencao/clientes`)

**Objetivo:** Listar e buscar clientes de manutenção.

**Campos de busca:** nome da empresa, nome da loja, responsável  
**Filtros:** status do contrato  
**Ações:** Ver detalhes, exportar CSV

---

### Tela: Orçamentos (`/manutencao/orcamentos`)

**Objetivo:** Gerenciar todos os orçamentos de serviços extras.

**Campos de busca:** cliente, título  
**Filtros:** status (em análise, em ajuste, aprovado, rejeitado, executado)  
**Cards de resumo:** total por status  
**Ações:** Responder orçamento (com upload de PDF), criar novo orçamento
